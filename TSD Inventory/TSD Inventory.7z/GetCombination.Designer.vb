﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GetCombination
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.gridPaperCombination = New System.Windows.Forms.DataGridView()
        Me.id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.outerliner = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.mid_liner = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.mid_liner2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.mid_liner3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.innerliner = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.gridPaperCombination, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdOK
        '
        Me.cmdOK.Location = New System.Drawing.Point(181, 301)
        Me.cmdOK.Margin = New System.Windows.Forms.Padding(5)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.Size = New System.Drawing.Size(121, 39)
        Me.cmdOK.TabIndex = 2
        Me.cmdOK.Text = "&OK"
        Me.cmdOK.UseVisualStyleBackColor = True
        '
        'gridPaperCombination
        '
        Me.gridPaperCombination.AllowUserToAddRows = False
        Me.gridPaperCombination.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.LightGoldenrodYellow
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        Me.gridPaperCombination.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.gridPaperCombination.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.gridPaperCombination.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridPaperCombination.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id, Me.outerliner, Me.mid_liner, Me.mid_liner2, Me.mid_liner3, Me.innerliner})
        Me.gridPaperCombination.Location = New System.Drawing.Point(1, 2)
        Me.gridPaperCombination.Margin = New System.Windows.Forms.Padding(5)
        Me.gridPaperCombination.MultiSelect = False
        Me.gridPaperCombination.Name = "gridPaperCombination"
        Me.gridPaperCombination.ReadOnly = True
        Me.gridPaperCombination.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.gridPaperCombination.Size = New System.Drawing.Size(481, 289)
        Me.gridPaperCombination.TabIndex = 3
        '
        'id
        '
        Me.id.DataPropertyName = "id"
        Me.id.HeaderText = "ID"
        Me.id.Name = "id"
        Me.id.ReadOnly = True
        Me.id.Width = 50
        '
        'outerliner
        '
        Me.outerliner.DataPropertyName = "outerliner"
        Me.outerliner.HeaderText = "Outer Liner"
        Me.outerliner.Name = "outerliner"
        Me.outerliner.ReadOnly = True
        Me.outerliner.Width = 75
        '
        'mid_liner
        '
        Me.mid_liner.DataPropertyName = "mid_liner"
        Me.mid_liner.HeaderText = "Mid Liner 1"
        Me.mid_liner.Name = "mid_liner"
        Me.mid_liner.ReadOnly = True
        Me.mid_liner.Width = 75
        '
        'mid_liner2
        '
        Me.mid_liner2.DataPropertyName = "mid_liner2"
        Me.mid_liner2.HeaderText = "Mid Liner 2"
        Me.mid_liner2.Name = "mid_liner2"
        Me.mid_liner2.ReadOnly = True
        Me.mid_liner2.Width = 75
        '
        'mid_liner3
        '
        Me.mid_liner3.DataPropertyName = "mid_liner3"
        Me.mid_liner3.HeaderText = "Mid Liner 3"
        Me.mid_liner3.Name = "mid_liner3"
        Me.mid_liner3.ReadOnly = True
        Me.mid_liner3.Width = 75
        '
        'innerliner
        '
        Me.innerliner.DataPropertyName = "InnerLiner"
        Me.innerliner.HeaderText = "Inner Liner"
        Me.innerliner.Name = "innerliner"
        Me.innerliner.ReadOnly = True
        Me.innerliner.Width = 75
        '
        'GetCombination
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(482, 354)
        Me.Controls.Add(Me.gridPaperCombination)
        Me.Controls.Add(Me.cmdOK)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "GetCombination"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Get Paper Combination"
        CType(Me.gridPaperCombination, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents gridPaperCombination As System.Windows.Forms.DataGridView
    Friend WithEvents id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents outerliner As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents mid_liner As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents mid_liner2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents mid_liner3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents innerliner As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
