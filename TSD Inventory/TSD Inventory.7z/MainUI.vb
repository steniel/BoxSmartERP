﻿Public Class MainUI
    Dim objPrintcard As ClassPrintcard
    'Local variables for Printcard
    Dim CustomerID As Integer
    Dim BoxDescription As String
    Dim BoxFormatID As Integer
    Dim FluteID As Integer
    Dim TestID As Integer
    Dim JointID As Integer
    Dim Paper_combinationID As Integer
    Dim DimensionID As Integer
    Dim Color1 As String
    Dim Color2 As String
    Dim color3 As String
    Dim Color4 As String
    Dim Flap As Integer
    Dim UnitID As Integer
    Dim ScaleID As Integer
    Dim DiecutID As Integer
    Dim PrintcardNo As Integer
    Dim FilenameID As Integer
    Dim CustomerFileID As Integer 'If available, will set this to foreign id file else will default to 1(i.e., no customer file attached
    Dim PrintcardCreated As String
    Public DocumentType As String 'Variable to determine of whether the printcard is New, Revised or Copied during the 'Save' command.
    Dim GlueTab, Panel1, Panel2, Panel3, Panel4 As Single
    Dim BoxHeight, BoardWidth, BoardLength As Double

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub NewPrintcardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewPrintcardToolStripMenuItem.Click
        'CreateNewPrintCard()
        Dim NewPrintcardForm As New PrintCard
        NewPrintcardForm.Show()
    End Sub
    Private Sub CreateNewPrintCard()
        Me.Cursor = Cursors.WaitCursor
        Dim p As ExportRptProgress = ExportRptProgress.ShowProgress(Me)
        Dim objForms As Form
        Dim n As Integer = Me.MdiChildren.Count
        If n > 0 Then
            For Each objForms In Me.MdiChildren
                If objForms.Name = PrintCard.Name Then
                    PrintCard.Activate()
                    PrintCard.Text = "New Printcard"
                Else
                    p.UpdateProgress(10, "10%", "Loading new printcard form...")
                    PrintCard.Show()
                    PrintCard.Text = "New Printcard"
                    p.UpdateProgress(100, "100%", "Loading new printcard form...")
                End If
            Next
        Else
            p.UpdateProgress(10, "10%", "Loading new printcard form...")
            PrintCard.Show()
            PrintCard.Text = "New Printcard"
            p.UpdateProgress(100, "100%", "Loading new printcard form...")
        End If
        p.CloseProgress()
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub RegisterColorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegisterColorToolStripMenuItem.Click
        ColorRegistration.Show()
    End Sub

    Private Sub tbDocumentSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tbDocumentSave.Click
        If PrintCard.Text = "Copy Printcard" Then
            SaveNewPrintcard()
        Else
            SaveNewPrintcard()
        End If
    End Sub

   
    Private Sub SaveNewPrintcard()
        Try
            Dim PrintcardSeriesID As Integer = 0
            Dim PrePrintcardNumber As Integer

            objPrintcard = New ClassPrintcard

            CheckVitalValues()

            Dim PrintcardNumber As Integer = PrintCard.tPrintcardNumber.Text
            CustomerID = PrintCard.customer_id
            If objPrintcard.CheckExistingPrincardNumber(CustomerID, PrintcardNumber) = 1 Then
                MsgBox("Printcard number was already in used for this customer.", MsgBoxStyle.Exclamation, "TSD Inventory System")
                PrintCard.tPrintcardNumber.Focus()
                PrintCard.tPrintcardNumber.SelectAll()
                Exit Sub
            End If

            PrePrintcardNumber = Convert.ToInt32(PrintCard.tPrintcardNumber.Text)
            PrePrintcardNumber = PrePrintcardNumber - 1

            'Prepare to upload printcard file and get id from the uploaded file
            Dim p As ExportRptProgress = ExportRptProgress.ShowProgress(Me)

            Dim sFileToUpload As String = ""
            Dim cCustomerFile As String = ""
            Dim CustomerFileExtension As String = ""
            p.UpdateProgress(10, "10%", "Uploading file to PostgreSQL server...")
            sFileToUpload = LTrim(RTrim(PrintCard.tFilePath.Text))


            'Check file extension to determine the file type
            Dim InternalGraphicExtension As String = System.IO.Path.GetExtension(sFileToUpload)

            If PrintCard.tCustomerFile.Text <> "" Then
                cCustomerFile = LTrim(RTrim(PrintCard.tCustomerFile.Text))
                CustomerFileExtension = System.IO.Path.GetExtension(cCustomerFile)
                Dim CustomerFileExtensionType As String = GetExtensionType(CustomerFileExtension)
                p.UpdateProgress(30, "30%", "Uploading customer file to PostgreSQL server...")
                CustomerFileID = objPrintcard.UploadCustomerFile(cCustomerFile, CustomerFileExtensionType)
            Else
                CustomerFileID = 1 ' No customer attached file
            End If

            Dim FileExtension As String = GetExtensionType(InternalGraphicExtension)
            p.UpdateProgress(40, "40%", "Uploading file to PostgreSQL server...")
            FilenameID = objPrintcard.upLoadImageOrFile(sFileToUpload, FileExtension)

            If objPrintcard.ErrorFlag = 4 Then
                p.CloseProgress()
                MsgBox("Error in uploading file. Please contact MIS immediately!", MsgBoxStyle.Exclamation & vbCritical, "TSD Inventory System")
                objPrintcard.ErrorFlag = 0
                Exit Sub
            End If
            p.UpdateProgress(100, "100%", "Uploading file to PostgreSQL server...")

            'Upload finished, with table filename's table ID value
            ' -------------------------------------------------------------------- 

            If PrintCard.DimensionID = 0 Then ' prepare to insert Inside Dimension and set the table ID
                p.UpdateProgress(10, "10%", "Inserting new Box Inside Dimension...")
                PrintCard.DimensionID = objPrintcard.InsertNewID(PrintCard.tLength.Text, PrintCard.tWidth.Text, PrintCard.tHeight.Text, PrintCard.UnitID)
                If objPrintcard.ErrorFlag = 3 Then
                    p.CloseProgress()
                    MsgBox("Error in Inserting New Inside Dimension. Press OK to rollback changes made to PostgreSQL database.", MsgBoxStyle.Exclamation & vbCritical, "TSD Inventory System")
                    objPrintcard.DeleteData("graphicfiles", FilenameID) 'Delete the saved graphic file
                    If PrintCard.tCustomerFile.Text <> "" Then 'Attachment should be remove also
                        objPrintcard.DeleteData("customerfile", CustomerFileID) ' Delete the saved customer file
                    End If
                    objPrintcard.ErrorFlag = 0
                    Exit Sub
                End If
                p.UpdateProgress(100, "100%", "Inserting new Box Inside Dimension...")
            End If

            'Save printcard series
            p.UpdateProgress(10, "10%", "Saving printcard series...")
            objPrintcard.InsertPrintcardSeries(PrintCard.customer_id, PrintCard.tPrintcardNumber.Text)
            If objPrintcard.ErrorFlag = 2 Then
                p.CloseProgress()
                MsgBox("Error in Inserting Printcard series number. Please contact MIS immediately!", MsgBoxStyle.Exclamation & vbCritical, "TSD Inventory System")
                objPrintcard.DeleteData("graphicfiles", FilenameID)  'Delete the saved graphic file
                If PrintCard.tCustomerFile.Text <> "" Then 'Attachment should be remove also
                    objPrintcard.DeleteData("customerfile", CustomerFileID) ' Delete the saved customer file
                End If
                objPrintcard.UpdateData("printcard_series", PrintcardSeriesID, "printcardno", PrePrintcardNumber) ' Update to the previous printcard number.
                objPrintcard.ErrorFlag = 0
                Exit Sub
            End If

            'Finally save Printcard 

            BoxDescription = PrintCard.tBoxDescription.Text
            BoxFormatID = PrintCard.BoxFormatID
            FluteID = PrintCard.cBoardTypeID
            TestID = PrintCard.cPSIID
            JointID = PrintCard.JointID
            Paper_combinationID = PrintCard.PaperCombinationID
            DimensionID = PrintCard.DimensionID
            Color1 = PrintCard.tColor1.Text
            Color2 = PrintCard.tColor2.Text
            color3 = PrintCard.tColor3.Text
            Color4 = PrintCard.tColor4.Text
            Flap = PrintCard.tFlap.Text
            UnitID = PrintCard.UnitID
            ScaleID = PrintCard.ScaleID
            DiecutID = PrintCard.Diecut_ID
            PrintcardNo = PrintCard.tPrintcardNumber.Text
            PrintcardCreated = PrintCard.cPrintcardCreated.Value.ToString
            'Box size
            BoardLength = PrintCard.tBoardLength.Text
            BoardWidth = PrintCard.tBoardWidth.Text
            BoxHeight = PrintCard.tBoxHeight.Text
            GlueTab = PrintCard.tGlueTab.Text
            Panel1 = PrintCard.tPanel1.Text
            Panel2 = PrintCard.tPanel2.Text
            Panel3 = PrintCard.tPanel3.Text
            Panel4 = PrintCard.tPanel4.Text

            'FilenameID see above.

            objPrintcard.SavePrintcard(CustomerID, _
                                       BoxDescription, _
                                       BoxFormatID, _
                                       FluteID, TestID, JointID, _
                                       Paper_combinationID, DimensionID, _
                                       Color1, Color2, color3, Color4, _
                                       Flap, UnitID, ScaleID, DiecutID, PrintcardNo, _
                                       FilenameID, PrintcardCreated, PrintCard.tPrintcardNotes.Text, _
                                       BoardLength, BoardWidth, BoxHeight, GlueTab, _
                                       Panel1, Panel2, Panel3, Panel4, CustomerFileID)
            If objPrintcard.ErrorFlag = 1 Then
                p.CloseProgress()
                MsgBox("Error in saving printcard. Please contact MIS immediately! Press OK to abort changes.", MsgBoxStyle.Exclamation & vbCritical, "TSD Inventory System")
                objPrintcard.DeleteData("graphicfiles", FilenameID) ' Delete the saved graphic file
                If PrintCard.tCustomerFile.Text <> "" Then 'Attachment should be remove also
                    objPrintcard.DeleteData("customerfile", CustomerFileID) ' Delete the saved customer file
                End If
                objPrintcard.UpdateData("printcard_series", CustomerID, "printcardno", PrePrintcardNumber) ' Update to the previous printcard number.
                objPrintcard.ErrorFlag = 0
                Exit Sub
            End If
            p.UpdateProgress(100, "100%", "Saving printcard...")
            p.CloseProgress()

            'Reset printcard form
            PrintCard.ResetForm()
            Dim objNewPrintcardNumber As Customer = New Customer
            PrintCard.tPrintcardNumber.Text = objNewPrintcardNumber.GetPrintcardNum(CustomerID)

            objNewPrintcardNumber = Nothing
        Catch ex As ApplicationException
            MsgBox(ex.Message & " Error in SaveNewPrintcard @ MainUI.vb", MsgBoxStyle.Critical, "TSD Inventory System")
        End Try        
    End Sub
    Private Sub CheckVitalValues()
        If PrintCard.tCustomerName.Text = "" Then
            MsgBox("Customer is required!")
            PrintCard.GetCustomer.Focus()
            Exit Sub
        End If

        If PrintCard.tBoxDescription.Text = "" Then
            MsgBox("Box description is required!")
            PrintCard.tBoxDescription.Focus()
            Exit Sub
        End If
        If PrintCard.tLength.Text = "" Or PrintCard.tWidth.Text = "" Or PrintCard.tHeight.Text = "" Then
            MsgBox("Inside dimension is required!")
            Exit Sub
        End If
        If PrintCard.tPaperCombination.Text = "" Then
            MsgBox("WARNING: No Paper combination entered!", MsgBoxStyle.Critical)
            PrintCard.cmdGetCombination.Focus()
            Exit Sub
        End If
        If PrintCard.tFilePath.Text = "" Then
            MsgBox("File(CDR/PDF) is required to save Printcard.")
            Exit Sub
        End If

    End Sub
    Private Function GetExtensionType(ByVal FileExtension As String) As String
        Dim ReturnExtension As String = ""
        FileExtension = LCase(FileExtension)
        If FileExtension = ".jpg" Or _
           FileExtension = ".bmp" Or _
           FileExtension = ".png" Or _
           FileExtension = ".jpeg" Or _
           FileExtension = ".tif" Then
            ReturnExtension = "Image"
        ElseIf FileExtension = ".cdr" Or _
           FileExtension = ".cdt" Or _
           FileExtension = ".cmx" Or _
           FileExtension = ".cdx" Or _
           FileExtension = ".cpx" Then
            ReturnExtension = "CorelDraw"
        ElseIf FileExtension = ".xcf" Then
            ReturnExtension = "GIMP"
        ElseIf FileExtension = ".cpt" Then
            ReturnExtension = "Photopaint"
        ElseIf FileExtension = ".ai" Then
            ReturnExtension = "Illustrator"
        ElseIf FileExtension = ".psd" Then
            ReturnExtension = "Photoshop"
        ElseIf FileExtension = ".pdf" Then
            ReturnExtension = "PDF File"
        Else
            ReturnExtension = "Unknown format"
        End If
        Return ReturnExtension
    End Function
    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click 
        CreateNewPrintCard()
    End Sub

    Private Sub CascadeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CascadeToolStripMenuItem.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub TileVerticalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TileVerticalToolStripMenuItem.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub TileHorizontalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TileHorizontalToolStripMenuItem.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        Me.Cursor = Cursors.WaitCursor
        cBrowsePrintcard()
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub cBrowsePrintcard()
        Dim objForms As Form
        Dim n As Integer = Me.MdiChildren.Count
        If n > 0 Then
            For Each objForms In Me.MdiChildren
                If objForms.Name = BrowsePrintcard.Name Then
                    BrowsePrintcard.Activate()
                Else
                    BrowsePrintcard.Show()
                End If
            Next
        Else
            BrowsePrintcard.Show()
        End If
    End Sub

    Private Sub MainUI_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        objPrintcard = Nothing
    End Sub

    Private Sub MainUI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        StatusMessage.Text = ""
    End Sub

    Private Sub BrowsePrintcardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowsePrintcardToolStripMenuItem.Click
        cBrowsePrintcard()
    End Sub

    Private Sub SavePrintcardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SavePrintcardToolStripMenuItem.Click
        SaveNewPrintcard()
    End Sub
End Class
