﻿Imports Npgsql
Public Class Customer
    Dim SQLConn As DataConnection = New DataConnection
    Public Function GetBoxInfo(ByVal CustomerID As Integer, ByVal PrintcardNumber As Integer, ByVal ColumnName As String) As Double     
        Dim iRes As Double
        Try
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "SELECT " & ColumnName & " FROM printcard WHERE customer_id=" & CustomerID & " AND printcardno=" & PrintcardNumber
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)

            While (SQLConn.dr.Read)
                If (SQLConn.dr.GetValue(0)) Is Nothing Then
                    iRes = 0
                ElseIf IsDBNull(SQLConn.dr.GetValue(0)) = False Then
                    iRes = SQLConn.dr.GetValue(0)
                End If
            End While
            SQLConn.conn.Close()
            SQLConn.conn.ClearPool()

        Catch ex As Npgsql.NpgsqlException
            MsgBox(ex.Message)  
        End Try

        Return iRes
    End Function
    Public Sub GetCustomerList(ByVal TableGrid As DataGridView)
 
        Try

            SQLConn.sql = "SELECT contact.id as id, contact.organization_name as orgname FROM (contact INNER JOIN customer ON customer.contact_id=contact.id) " & _
                 " WHERE contact.deleted=0 AND customer.current_status='Active'"

            SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
            SQLConn.da.Fill(SQLConn.ds, "customer")
            TableGrid.DataSource = SQLConn.ds.Tables("customer")

        Catch ex As Npgsql.NpgsqlException
            MsgBox(ex.Message)
        Catch ex As ApplicationException
            MsgBox(ex.Message)
        End Try
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

    End Sub
    'Select Board type
    Public Sub GetBoardType(ByVal ComboBox As ComboBox)
        
        SQLConn.sql = "select (flute || '-') || description as boardtype FROM flute"
        SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
        SQLConn.da.Fill(SQLConn.ds, "flute")
        ComboBox.DataSource = SQLConn.ds.Tables("flute")
        ComboBox.DisplayMember = "boardtype"

        SQLConn.da.Dispose()
        SQLConn.ds.Dispose()
        SQLConn.conn.ClearPool()

    End Sub
    'Select Board type ID
    Public Function GetBoardTypeID(ByVal value As String) As Integer        
        Dim id As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT id FROM flute WHERE (flute || '-') || description='" & value & "'"
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            id = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
        Return id
    End Function
    'GET PSI Data from table
    Public Sub GetPSI(ByVal ComboBox As ComboBox)

        SQLConn.sql = "select value FROM test"
        SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
        SQLConn.da.Fill(SQLConn.ds, "test")
        ComboBox.DataSource = SQLConn.ds.Tables("test")
        ComboBox.DisplayMember = "value"

        SQLConn.da.Dispose()
        SQLConn.ds.Dispose()
        SQLConn.conn.ClearPool()
    End Sub
    'Get Diecut list
    Public Sub GetDiecut(ByVal ComboBox As ComboBox)
        SQLConn.sql = "select diecut_number FROM diecut WHERE deleted=0"
        SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
        SQLConn.da.Fill(SQLConn.ds, "diecut")
        ComboBox.DataSource = SQLConn.ds.Tables("diecut")
        ComboBox.DisplayMember = "diecut_number"

        SQLConn.da.Dispose()
        SQLConn.ds.Dispose()
        SQLConn.conn.ClearPool()
    End Sub
    'Get JOINT types
    Public Sub GetJoint(ByVal ComboBox As ComboBox)
        SQLConn.sql = "select description FROM joint"
        SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
        SQLConn.da.Fill(SQLConn.ds, "joint")
        ComboBox.DataSource = SQLConn.ds.Tables("joint")
        ComboBox.DisplayMember = "description"

        SQLConn.da.Dispose()
        SQLConn.ds.Dispose()
        SQLConn.conn.ClearPool()
    End Sub

    Public Function GetJointID(ByVal Description As String) As Integer
        Dim id As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT id FROM joint WHERE description='" & Description & "'"
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            id = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
        Return id
    End Function

    'Get Diecut ID
    Public Function GetDiecutID(ByVal DiecutNumber As Integer) As Integer
        Dim id As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT id FROM diecut WHERE diecut_number=" & DiecutNumber
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            id = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
        Return id
    End Function
    'Get PSI test ID
    Public Function GetTestID(ByVal value As Integer) As Integer

        Dim id As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT id FROM test WHERE value=" & value
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            id = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
        Return id

    End Function
    Private Function GetCBTypeCombination(ByVal Flute As String) As Integer
        Dim cCount As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        If Flute = "CB-Flute" Then
            SQLConn.sql = "SELECT count(*) FROM paper_combination WHERE mid_liner IS NOT NULL " & _
                      "AND mid_liner2 IS NOT NULL " & _
                      "AND mid_liner3 IS NOT NULL "
        Else
            SQLConn.sql = "SELECT count(*) FROM paper_combination WHERE mid_liner IS NOT NULL "
        End If

        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            cCount = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
        Return cCount
        MsgBox(cCount)
    End Function
    'Get paper combination
    Public Sub GetPaperCombination(ByVal DataGrid As DataGridView, ByVal FluteType As String)


        Try
            If FluteType = "CB-Flute" Then
                'If GetCBTypeCombination("CB-Flute") > 0 Then 'TODO: Query is correct but their is no result greater than zero, need debug to work
                '    DataGrid.DataSource = Nothing
                '    Exit Sub
                'End If
                SQLConn.sql = "SELECT id,(outer_liner || " & _
                                "CASE outer_color WHEN 'Brown' THEN ' BKL' " & _
                                    "WHEN 'White' THEN ' WKL' " & _
                                    "ELSE 'other' " & _
                                "END)as OuterLiner, " & _
                            "mid_liner,mid_liner2,mid_liner3,(inner_liner || " & _
                                "CASE inner_color WHEN 'Brown' THEN ' BKL' " & _
                                    "WHEN 'White' THEN ' WKL' " & _
                                    "ELSE 'other' " & _
                                "END) as InnerLiner " & _
                "FROM paper_combination WHERE mid_liner IS NOT NULL AND mid_liner2 IS NOT NULL AND mid_liner3 IS NOT NULL;"
            Else
                If GetCBTypeCombination("C-Flute") = 0 Then 'Any text other than CB-Flute; Check for record count of paper board C-flute type
                    DataGrid.DataSource = Nothing
                    Exit Sub
                End If
                SQLConn.sql = "SELECT id,(outer_liner || " & _
                                "CASE outer_color WHEN 'Brown' THEN ' BKL' " & _
                                    "WHEN 'White' THEN ' WKL' " & _
                                    "ELSE 'other' " & _
                                "END)as OuterLiner, " & _
                            "mid_liner,(inner_liner || " & _
                                "CASE inner_color WHEN 'Brown' THEN ' BKL' " & _
                                    "WHEN 'White' THEN ' WKL' " & _
                                    "ELSE 'other' " & _
                                "END) as InnerLiner " & _
                "FROM paper_combination;"
            End If

            SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
            SQLConn.da.Fill(SQLConn.ds, "customer")
            DataGrid.DataSource = SQLConn.ds.Tables("customer")

        Catch ex As Npgsql.NpgsqlException
            MsgBox(ex.Message)
        Catch ex As ApplicationException
            MsgBox(ex.Message)
        End Try

        SQLConn.conn.ClearPool()

    End Sub
    'Get Box format (RSC/HSC) etc.
    Public Sub GetBoxFormat(ByVal ComboBox As ComboBox)

        SQLConn.sql = "select description FROM boxformat"
        SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
        SQLConn.da.Fill(SQLConn.ds, "boxformat")
        ComboBox.DataSource = SQLConn.ds.Tables("boxformat")
        ComboBox.DisplayMember = "description"

        SQLConn.da.Dispose()
        SQLConn.ds.Dispose()
        SQLConn.conn.ClearPool()

    End Sub
    Public Function GetIndustryType(ByVal CustomerID As Integer) As Short
        Dim rIndType As Short

        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT industry_type_id FROM customer WHERE id=" & CustomerID
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            rIndType = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return rIndType

    End Function
    'Get Box Format ID
    Public Function GetBoxFormatID(ByVal value As String) As Integer

        Dim id As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT id FROM boxformat WHERE description='" & value & "'"
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            id = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
        Return id
    End Function

    Public Function GetCustomerPrefix(ByVal UserID As Integer) As String
        Dim prefix As String = ""
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT printcard_prefix FROM customer WHERE contact_id=" & UserID
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            prefix = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return prefix

    End Function

    Public Function GetPrintcardNum(ByVal UserID As Integer) As Integer
        Dim PrintcardNum As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT printcardno+1 as PrintcardNumber FROM printcard_series WHERE customer_id=" & UserID
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            PrintcardNum = SQLConn.dr.GetValue(0)
        End While
        'If customer doesn't yet exist in the table
        If PrintcardNum = 0 Then
            'Insert is not possible if user will cancel printcard creation
            'SQLConn.sql = "INSERT INTO printcard_series(customer_id,printcardno)VALUES(" & UserID & ",1)"
            'SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            'SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
            PrintcardNum = 1 'Set printcard series as #1
        End If
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return PrintcardNum
    End Function

    Public Function GetInsideDimension(ByVal DimensionID As Integer, ByVal BoxSide As String) As Integer
        Dim idval As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT " & BoxSide & " FROM paper_dimension WHERE id=" & DimensionID
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            idval = SQLConn.dr.GetValue(0)
        End While

        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return idval
    End Function

    Public Function GetCombination(ByVal PaperCombinationID As Integer, ByVal FluteType As String) As String
        Dim PaperCombination As String = ""
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        If FluteType = "CB-Flute" Then
            SQLConn.sql = "SELECT (outer_liner ||  " & _
                            " CASE outer_color WHEN 'Brown' THEN ' BKL'  " & _
                            "   WHEN 'White' THEN ' WKL'  " & _
                            " Else 'other'  END)as OuterLiner," & _
                            " mid_liner,mid_liner2,mid_liner3,(inner_liner ||  " & _
                          " CASE inner_color WHEN 'Brown' THEN ' BKL'  " & _
                             " WHEN 'White' THEN ' WKL'   " & _
                          " ELSE 'other'  " & _
                          " END) as InnerLiner  " & _
                            " FROM paper_combination WHERE mid_liner IS NOT NULL AND mid_liner2 IS NOT NULL AND mid_liner3 IS NOT NULL;"
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While (SQLConn.dr.Read)
                PaperCombination = SQLConn.dr.GetValue(0) & " X " & SQLConn.dr.GetValue(1) _
                                   & " X " & SQLConn.dr.GetValue(2) & " X " & SQLConn.dr.GetValue(3) _
                                   & " X " & SQLConn.dr.GetValue(4)
            End While
        Else
            SQLConn.sql = "SELECT (outer_liner || " & _
                                "CASE outer_color WHEN 'Brown' THEN ' BKL' " & _
                                    "WHEN 'White' THEN ' WKL' " & _
                                    "ELSE 'other' " & _
                                "END)as OuterLiner, " & _
                            "mid_liner,(inner_liner || " & _
                                "CASE inner_color WHEN 'Brown' THEN ' BKL' " & _
                                    "WHEN 'White' THEN ' WKL' " & _
                                    "ELSE 'other' " & _
                                "END) as InnerLiner " & _
                "FROM paper_combination;"
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While (SQLConn.dr.Read)
                PaperCombination = SQLConn.dr.GetValue(0) & " X " & SQLConn.dr.GetValue(1) & " X " & SQLConn.dr.GetValue(2)
            End While
        End If        
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return PaperCombination
    End Function
End Class
