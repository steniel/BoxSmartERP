﻿Public Class BrowsePrintcard    
    Dim MonthNumber As String
    Public YearToday As DateTime
    Public YearVal As String
    Public YearMonth As String
    Dim CustomerFileID As Integer = 0
    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.Close()
    End Sub

    Private Sub BrowsePrintcard_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        If txtYear.Text = "" Then
            YearToday = Date.Now
            YearVal = YearToday.ToString("yyyy")
            YearMonth = YearToday.ToString("MMMM")
            cmbNumRecords.Text = "100"
            txtYear.Text = YearVal
            'cmbMonth.Text = YearMonth
            cmbMonth.Text = "All Year Round"
        End If
    End Sub

    Private Sub BrowsePrintcard_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Timer1.Stop()        
    End Sub

    Private Sub BrowsePrintcard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.MdiParent = MainUI
        Dim objPrintcard As ClassPrintcard
        objPrintcard = New ClassPrintcard
        objPrintcard.GetPrintcardList(Me.PrintcardGrid, txtYear.Text, MonthNumber, cmbNumRecords.Text)

        For cols As Integer = 2 To 9
            gridColumn.Items.Add(PrintcardGrid.Columns(cols).HeaderText)
        Next
        gridColumn.Text = "Customer"
        Timer1.Start()
        objPrintcard = Nothing
    End Sub
    Private Sub LoadData()
        Dim objPrintcard As ClassPrintcard
        objPrintcard = New ClassPrintcard
        objPrintcard.GetPrintcardList(Me.PrintcardGrid, txtYear.Text, MonthNumber, cmbNumRecords.Text)
        lCountRows.Text = "Rows: " & PrintcardGrid.RowCount
        objPrintcard = Nothing
    End Sub
   
    Private Sub cmdViewPrintcard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdViewPrintcard.Click
        Dim objPrintcard As ClassPrintcard = New ClassPrintcard
        Dim id As Integer = 0
        Dim FileType As String = ""
        Dim FileName As String = ""
        For Each cPrintcards In PrintcardGrid.SelectedRows
            id = cPrintcards.cells("fileid").value 'Filename ID
            FileType = cPrintcards.cells("filetype").value
            FileName = cPrintcards.cells("filename").value
        Next
        objPrintcard.downLoadFile(id, FileName, FileType)
        objPrintcard = Nothing
    End Sub

    Public Shared Function SearchGridValue(ByVal dtg As DataGridView, ByVal ColumnName As String, ByVal ValueToSearch As String) As Boolean
        Dim Found As Boolean = False
        Dim StringToSearch As String = ""
        Dim ValueToSearchFor As String = ValueToSearch.Trim.ToLower
        Dim CurrentRowIndex As Integer = 0
        Try
            If dtg.Rows.Count = 0 Then
                CurrentRowIndex = 0
            Else
                CurrentRowIndex = dtg.CurrentRow.Index + 1
            End If
            If CurrentRowIndex > dtg.Rows.Count Then
                CurrentRowIndex = dtg.Rows.Count - 1
            End If
            If dtg.Rows.Count > 0 Then
                For Each gRow As DataGridViewRow In dtg.Rows
                    StringToSearch = gRow.Cells(ColumnName).Value.ToString.Trim.ToLower
                    If StringToSearch.Contains(ValueToSearchFor) Then
                        Dim myCurrentCell As DataGridViewCell = gRow.Cells(ColumnName)
                        dtg.CurrentCell = myCurrentCell
                        Found = True
                    End If
                    If Found Then
                        Exit For
                    End If
                Next
            End If
            If Not Found Then
                If dtg.Rows.Count > 0 Then
                    Dim myFirstCurrentCell As DataGridViewCell = dtg.Rows(0).Cells(ColumnName)
                    dtg.CurrentCell = myFirstCurrentCell
                End If
            End If
        Catch ex As Exception
            MsgBox("Error: " & ex.Message, MsgBoxStyle.Information)
        End Try
        Return Found
    End Function

    Private Sub txtYear_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtYear.KeyPress
        Dim allowedChars As String = "1234567890" & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtYear_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtYear.TextChanged
        If txtYear.TextLength > 4 Then
            SendKeys.Send(ControlChars.Back)
        ElseIf txtYear.TextLength = 4 Then
            LoadData()
        End If
    End Sub

    Private Sub cmbMonth_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbMonth.SelectedIndexChanged
        Select Case cmbMonth.Text
            Case "January"
                MonthNumber = "01"
                LoadData()
            Case "February"
                MonthNumber = "02"
                LoadData()
            Case "March"
                MonthNumber = "03"
                LoadData()
            Case "April"
                MonthNumber = "04"
                LoadData()
            Case "May"
                MonthNumber = "05"
                LoadData()
            Case "June"
                MonthNumber = "06"
                LoadData()
            Case "July"
                MonthNumber = "07"
                LoadData()
            Case "August"
                MonthNumber = "08"
                LoadData()
            Case "September"
                MonthNumber = "09"
                LoadData()
            Case "October"
                MonthNumber = "10"
                LoadData()
            Case "November"
                MonthNumber = "11"
                LoadData()
            Case "December"
                MonthNumber = "12"
                LoadData()
            Case Else
                MonthNumber = ""
                LoadData()
        End Select
    End Sub

    Private Sub cmdSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        Dim ColumnName As String = ""
        Select Case gridColumn.Text
            Case "Customer"
                ColumnName = "organization_name"
            Case "Filename"
                ColumnName = "filename"
            Case "Box Description"
                ColumnName = "box_description"
            Case "Inside Dimension"
                ColumnName = "insidedimension"
            Case "Board Size"
                ColumnName = "boardsize"
            Case "Printcard No."
                ColumnName = "printcardno"
            Case "Diecut #"
                ColumnName = "diecut_number"
            Case "Rack Location"
                ColumnName = "racklocation"
        End Select

        If SearchGridValue(Me.PrintcardGrid, ColumnName, cSearchThis.Text) = False Then
            MainUI.StatusMessage.Text = "'" & cSearchThis.Text & "' cannot be found using column: " & gridColumn.Text & "!"
            MainUI.StatusMessage.ForeColor = Color.Red
        Else
            MainUI.StatusMessage.ForeColor = Color.Black
            MainUI.StatusMessage.Text = "'" & cSearchThis.Text & "' was found at row #: " & PrintcardGrid.CurrentRow.Index + 1
        End If
    End Sub

    Private Sub cmbNumRecords_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbNumRecords.KeyPress
        Dim allowedChars As String = "1234567890" & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub PrintcardGrid_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrintcardGrid.SelectionChanged
        Try
            If PrintcardGrid.SelectedRows.Count = 0 Then
                cmdViewPrintcard.Enabled = False
                cmdCreateCopy.Enabled = False
                lCurrentSel.Text = "File ID selected: None"
            Else
                cmdViewPrintcard.Enabled = True
                cmdCreateCopy.Enabled = True
                For Each cPrintcards In PrintcardGrid.SelectedRows
                    lCurrentSel.Text = "File ID selected: " & cPrintcards.cells("fileid").value
                    CustomerFileID = cPrintcards.cells("customer_file_id").value
                Next
            End If
            If CustomerFileID = 1 Then
                cmdViewCustomerFile.Enabled = False
            Else
                cmdViewCustomerFile.Enabled = True
            End If
        Catch ex As ArgumentException
            MsgBox(ex.Message & Chr(13) & "! Error in PrintcardGrid_SelectionChanged @BrowsePrintcard.vb form",MsgBoxStyle.Critical,"TSD Inventory System")
        End Try        
    End Sub

    Private Sub cmdCreateCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreateCopy.Click
        'Check revision # @table revision
        Dim PrintcardCopyForm As New PrintCard
        Dim objCustomerList As Customer = New Customer
        Dim p As ExportRptProgress = ExportRptProgress.ShowProgress(Me)        
        Me.Cursor = Cursors.WaitCursor  
        Dim objForms As Form
        Dim n As Integer = MainUI.MdiChildren.Count       
        If n > 0 Then
            For Each objForms In MainUI.MdiChildren
                If objForms.Name = PrintcardCopyForm.Name Then
                    p.CloseProgress()
                    Me.Cursor = Cursors.Default
                    MsgBox("Printcard form is already active. You need to close the form before creating a copy.", MsgBoxStyle.Exclamation, "TSD Inventory System")
                    Exit Sub
                Else
                    p.UpdateProgress(10, "10%", "Loading printcard form...")
                    PrintcardCopyForm.Show()
                    PrintcardCopyForm.Text = "Copy Printcard"
                End If
            Next
        Else
            p.UpdateProgress(10, "10%", "Loading printcard form...")
            PrintcardCopyForm.Show()
            PrintcardCopyForm.Text = "Copy Printcard"
        End If


        Dim id As Integer = 0
        Dim FileType As String = ""
        Dim CustomerID As Integer = 0
        Dim FileName As String = ""
        Dim CustomerName As String = ""
        Dim BoxDesc As String = ""
        Dim boardtypeid As String = ""
        Dim testid As Short = 0
        Dim boxformatid As Integer = 0
        Dim CombinationID As Integer = 0
        Dim dimensionid As Integer = 0
        Dim revisionid As Integer = 0
        Dim fluteid As String = ""
        Dim diecutid As Integer = 0
        Dim jointid As String = ""
        Dim scale_id As String = ""
        Dim color1 As String = ""
        Dim color2 As String = ""
        Dim color3 As String = ""
        Dim color4 As String = ""
        Dim PrintcardNumber As Integer
        p.UpdateProgress(50, "50%", "Loading printcard form...")
        For Each cPrintcards In PrintcardGrid.SelectedRows
            id = cPrintcards.cells("fileid").value 'Filename ID
            FileType = cPrintcards.cells("filetype").value
            FileName = cPrintcards.cells("filename").value
            CustomerName = cPrintcards.cells("organization_name").value
            CustomerID = cPrintcards.cells("id").value
            BoxDesc = cPrintcards.cells("box_description").value
            color1 = cPrintcards.cells("color1").value
            color2 = cPrintcards.cells("color2").value
            color3 = cPrintcards.cells("color3").value
            color4 = cPrintcards.cells("color4").value
            boardtypeid = cPrintcards.cells("boardtypeid").value
            testid = cPrintcards.cells("testid").value
            fluteid = cPrintcards.cells("fluteid").value
            diecutid = cPrintcards.cells("diecut_number").value
            jointid = cPrintcards.cells("jointid").value
            CombinationID = cPrintcards.cells("combinationid").value
            dimensionid = cPrintcards.cells("dimensionid").value
            scale_id = cPrintcards.cells("scaleid").value
            PrintcardNumber = cPrintcards.cells("printcopyno").value
        Next

        PrintcardCopyForm.tColor1.Text = color1
        PrintcardCopyForm.tColor2.Text = color2
        PrintcardCopyForm.tColor3.Text = color3
        PrintcardCopyForm.tColor4.Text = color4
        PrintcardCopyForm.tBoxDescription.Text = BoxDesc
        PrintcardCopyForm.cmbBoardType.Text = fluteid
        PrintcardCopyForm.cmbDiecut.Text = diecutid
        PrintcardCopyForm.cmbBoxFormat.Text = boardtypeid
        PrintcardCopyForm.cmbPSI.Text = testid
        PrintcardCopyForm.cmbJoint.Text = jointid
        PrintcardCopyForm.cmbScale.Text = scale_id

        PrintcardCopyForm.PaperCombinationID = CombinationID
        PrintcardCopyForm.tPrintcardNumber.Text = objCustomerList.GetPrintcardNum(CustomerID)
        PrintcardCopyForm.tLength.Text = objCustomerList.GetInsideDimension(dimensionid, "length")
        PrintcardCopyForm.tWidth.Text = objCustomerList.GetInsideDimension(dimensionid, "width")
        PrintcardCopyForm.tHeight.Text = objCustomerList.GetInsideDimension(dimensionid, "height")
        PrintcardCopyForm.tPaperCombination.Text = objCustomerList.GetCombination(CombinationID, fluteid)

        PrintcardCopyForm.tPanel1.Text = objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "panel1")
        PrintcardCopyForm.tPanel2.Text = objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "panel2")
        PrintcardCopyForm.tPanel3.Text = objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "panel3")
        PrintcardCopyForm.tPanel4.Text = objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "panel4")
        PrintcardCopyForm.tBoardLength.Text = objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "boardlength")
        PrintcardCopyForm.tBoardWidth.Text = objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "boardwidth")
        PrintcardCopyForm.tBoxHeight.Text = objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "boxheight")
        PrintcardCopyForm.tFlap.Text = objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "flap")

        If objCustomerList.GetBoxInfo(CustomerID, PrintcardNumber, "gluetab") = 0 Then
            PrintcardCopyForm.ComputeBoxSize()
        End If
        PrintcardCopyForm.customer_id = CustomerID

        p.UpdateProgress(60, "60%", "Loading printcard form...")
        PrintcardCopyForm.tCustomerName.Text = CustomerName
        PrintcardCopyForm.tPrincardPrefix.Text = objCustomerList.GetCustomerPrefix(CustomerID) & "-PC-"
        PrintcardCopyForm.tPrintcardNumber.Text = objCustomerList.GetPrintcardNum(CustomerID)
        p.UpdateProgress(80, "80%", "Loading printcard form...")
        objCustomerList = Nothing
        p.UpdateProgress(100, "100%", "Loading printcard form...")
        Me.Cursor = Cursors.Default
        p.CloseProgress()
    End Sub

    Private Sub cmdRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        LoadData()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        LoadData()
    End Sub

    Private Sub cmdSearchDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearchDB.Click
        Dim ColumnName As String = ""
        Select Case gridColumn.Text
            Case "Customer"
                ColumnName = "contact.organization_name"
            Case "Filename"
                ColumnName = "graphicfiles.filename"
            Case "Box Description"
                ColumnName = "printcard.box_description"
            Case "Inside Dimension"
                ColumnName = "(trim(to_char(paper_dimension.length,'999999')) || ' X ' || trim(to_char(paper_dimension.width,'99999')) || ' X ' || trim(to_char(paper_dimension.height,'99999')))"
            Case "Board Size"
                ColumnName = "trim(to_char(printcard.boardlength,'999999')) || ' X ' || trim(to_char(printcard.boardwidth,'999999'))"
            Case "Printcard No."
                ColumnName = "printcard.printcardno"
            Case "Diecut #"
                ColumnName = "diecut.diecut_number"
            Case "Rack Location"
                ColumnName = "(racks.rack_number || racks.rack_column)"
        End Select
        Dim objPrintcard As ClassPrintcard = New ClassPrintcard
        objPrintcard.Search(Me.PrintcardGrid, txtYear.Text, MonthNumber, ColumnName, cSearchThis.Text, cmbNumRecords.Text)
        objPrintcard = Nothing
    End Sub

    Private Sub cmdViewCustomerFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdViewCustomerFile.Click
        Dim objPrintcard As ClassPrintcard = New ClassPrintcard        
        Dim FileType As String = ""
        Dim FileName As String = ""
        Dim BoxDescription As String = ""
        Dim PrintcardNumber As String = ""
        For Each cPrintcards In PrintcardGrid.SelectedRows
            CustomerFileID = cPrintcards.cells("customer_file_id").value 'Filename ID
            BoxDescription = cPrintcards.cells("box_description").value
            PrintcardNumber = cPrintcards.cells("printcardno").value
            If CustomerFileID = 1 Then
                MsgBox("There is no customer file attachment for Printcard #: " & PrintcardNumber & " with description: " & BoxDescription, MsgBoxStyle.Exclamation, "TSD Inventory System")
                Exit Sub
            End If
            FileType = cPrintcards.cells("customerfiletype").value
            FileName = cPrintcards.cells("customerfile").value            
        Next       
        objPrintcard.ViewCustomerFile(CustomerFileID, FileName, FileType)
        objPrintcard = Nothing
    End Sub

    Private Sub PrintcardGrid_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PrintcardGrid.CellContentClick

    End Sub
End Class