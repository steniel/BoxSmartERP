﻿Public Class Diecut

    Private Sub Diecut_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.MdiParent = MainUI
    End Sub
End Class