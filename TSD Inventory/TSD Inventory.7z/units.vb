﻿Imports Npgsql
Public Class units
    Dim SQLConn As DataConnection = New DataConnection
    'Get Box format (RSC/HSC) etc.
    Public Sub UnitTable(ByVal ComboBox As ComboBox)

        SQLConn.sql = "select prefix FROM unit_table"
        SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
        SQLConn.da.Fill(SQLConn.ds, "unit_table")
        ComboBox.DataSource = SQLConn.ds.Tables("unit_table")
        ComboBox.DisplayMember = "prefix"

        SQLConn.da.Dispose()
        SQLConn.ds.Dispose()
        SQLConn.conn.ClearPool()

    End Sub

    Public Sub PageScale(ByVal ComboBox As ComboBox)

        SQLConn.sql = "select description FROM scale"
        SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
        SQLConn.da.Fill(SQLConn.ds, "scale")
        ComboBox.DataSource = SQLConn.ds.Tables("scale")
        ComboBox.DisplayMember = "description"

        SQLConn.da.Dispose()
        SQLConn.ds.Dispose()
        SQLConn.conn.ClearPool()

    End Sub

    Public Function PageScaleID(ByVal value As String) As Integer
        Dim id As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT id FROM scale WHERE description='" & value & "'"
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            id = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return id

    End Function

    Public Function GetUnitID(ByVal value As String) As Integer

        Dim id As Integer
        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "SELECT id FROM unit_table WHERE prefix='" & value & "'"
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (SQLConn.dr.Read)
            id = SQLConn.dr.GetValue(0)
        End While
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return id
    End Function
End Class
