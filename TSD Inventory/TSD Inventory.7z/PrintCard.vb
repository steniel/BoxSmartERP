﻿Imports System.IO

Public Class PrintCard
    Public customer_id As Integer
    Public Customer_Name As String
    Public PaperCombinationID As Integer
    Public PreviousFlute As String 'If flute was changed to CB-Flute then save the previous flute to this variable
    Dim objCustomer As Customer = New Customer
    Dim objPaper As PaperDimension = New PaperDimension
    Dim objUnits As units = New units
    Public BoxFormatID As Integer
    Public DimensionID As Integer
    Public Diecut_ID As Integer
    Public cBoardTypeID As Integer
    Public cPSIID As Integer
    Public ScaleID As Integer
    Public UnitID As Integer
    Public JointID As Integer
    Dim NotesCharCount As Short = 255

    'Compute box, need to set this to reduce server usage tax, we only need to query the values where there are changes in Boxtype, Joint and Flute
    Dim factor1 As Short
    Dim factor2 As Short
    Dim factor3 As Short
    Dim factor4 As Short

    Dim GlueTab As Single
    Dim FactorFlap As Single
    Dim FactorHeight As Single
    Dim BoxFormatType As String = ""
    Dim Panel1, Panel2, Panel3, Panel4 As Single
    Dim BoxHeight, BoardWidth, BoardLength, BoxFlap As Double



    Private Sub PrintCard_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        MainUI.tbDocumentSave.Enabled = True
        MainUI.SavePrintcardToolStripMenuItem.Enabled = True        
    End Sub

    Private Sub PrintCard_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        MainUI.tbDocumentSave.Enabled = False
        MainUI.SavePrintcardToolStripMenuItem.Enabled = False
    End Sub

    Private Sub PrintCard_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        objCustomer = Nothing
        objPaper = Nothing
        objUnits = Nothing
    End Sub
    Private Sub PrintCard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.MdiParent = MainUI
        objCustomer.GetBoardType(Me.cmbBoardType)
        objCustomer.GetPSI(Me.cmbPSI)
        objCustomer.GetBoxFormat(Me.cmbBoxFormat)
        objUnits.UnitTable(Me.cmbUnits)
        objUnits.PageScale(Me.cmbScale)
        objCustomer.GetDiecut(Me.cmbDiecut)
        objCustomer.GetJoint(Me.cmbJoint)
        cmbScale.Text = "1:8"
        tColor1.Text = "N/A"
        tColor2.Text = "N/A"
        tColor3.Text = "N/A"
        tColor4.Text = "N/A"
        MainUI.StatusMessage.Text = ""
    End Sub

    Private Sub GetCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetCustomer.Click, cmdCompute.Click
        Me.Cursor = Cursors.WaitCursor
        CustomerList.ShowDialog()
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub cmbBoardType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbBoardType.Click
        PreviousFlute = cmbBoardType.Text
    End Sub

    Private Sub cmbBoardType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbBoardType.SelectedIndexChanged
        boardID.Text = objCustomer.GetBoardTypeID(cmbBoardType.Text)
        tPaperCombination.Text = ""
        tOuterLiner.Text = ""
        cBoardTypeID = boardID.Text
        If cmbBoardType.Text = "CB-Flute" Then
            cmbPSI.Text = "350"
        End If
        SetFactorValues() ' Query for changes in factor values
        ComputeBoxSize()
    End Sub

    Private Sub cmbPSI_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbPSI.SelectedIndexChanged
        'psi_id.Text = objCustomer.GetTestID(cmbPSI.Text)
        'Get Test ID
        If cmbPSI.Text <> "System.Data.DataRowView" Then 'casting error
            PSI_id.Text = objCustomer.GetTestID(cmbPSI.Text)
            cPSIID = PSI_id.Text
        End If
    End Sub


    Private Sub cmdGetCombination_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGetCombination.Click
        GetCombination.ShowDialog()
    End Sub

    Private Sub cmbBoxFormat_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbBoxFormat.SelectedIndexChanged
        BoxFormatID = objCustomer.GetBoxFormatID(cmbBoxFormat.Text)
        lBoxFormatId.Text = BoxFormatID
        SetFactorValues()
        ComputeBoxSize()
    End Sub

    Private Function CheckID(ByVal Length As TextBox, ByVal Width As TextBox, ByVal Height As TextBox) As Boolean
        If Length.TextLength = 0 Or Width.TextLength = 0 Or Height.TextLength = 0 Then
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub theight_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tHeight.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub theight_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tHeight.LostFocus
        If CheckID(Me.tLength, Me.tWidth, Me.tHeight) = True Then
            lDimensionID.Text = objPaper.CheckExistingDimension(tLength.Text, tWidth.Text, tHeight.Text)
            DimensionID = lDimensionID.Text
        Else
            lDimensionID.Text = 0
            DimensionID = 0
        End If
    End Sub

    Private Sub tLength_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tLength.GotFocus, tWidth.GotFocus, tHeight.GotFocus
        If tLength.Focused Then tLength.SelectAll()
        If tWidth.Focused Then tWidth.SelectAll()
        If tHeight.Focused Then tHeight.SelectAll()
    End Sub
    Private Sub cmbUnits_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbUnits.SelectedIndexChanged
        lUnitID.Text = objUnits.GetUnitID(cmbUnits.Text)
        UnitID = lUnitID.Text
    End Sub

    Private Sub cmbScale_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbScale.SelectedIndexChanged
        lScaleID.Text = objUnits.PageScaleID(cmbScale.Text)
        ScaleID = lScaleID.Text
    End Sub

    Private Sub cmbDiecut_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbDiecut.SelectedIndexChanged
        'Diecut_ID = objCustomer.GetDiecutID(cmbDiecut.Text)
        If cmbDiecut.Text <> "System.Data.DataRowView" Then
            Diecut_ID = objCustomer.GetDiecutID(cmbDiecut.Text)
            lDiecut.Text = "DiecutID: " & Diecut_ID
        End If

    End Sub

    Private Sub cmdBrowseFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBrowseFile.Click
        BrowseFile()
    End Sub

    Private Sub BrowseFile()
        UploadPrintcardFile.Filter = "Portable Document Format(PDF) File (*.pdf)|*.pdf;|" & _
                                     "CorelDraw Graphic Files(CDR) Files (*.cdr,*.cdt,*.cmx)|*.cdr;*.cdt;*.cmx;|" & _
                                     "Corel Photopaint (*.cpt)|*.cpt;|" & _
                                     "Adobe Illustrator (*.ai)|*.ai;|" & _
                                     "Adobe Photoshop (*.psd)|*.psd;|" & _
                                     "GIMP (*.xcf)|*.xcf;|" & _
                                     "Image Files (*.bmp, *.jpg, *.jpeg, *.tif)|*.bmp;*.jpg;*.jpeg;*.tif;"
        UploadPrintcardFile.FileName = ""
        UploadPrintcardFile.ShowDialog()
        tFilePath.Text = UploadPrintcardFile.FileName
        Dim FileExtension As String
        FileExtension = LTrim(RTrim(tFilePath.Text))
        Dim Extension As String = System.IO.Path.GetExtension(FileExtension)

        If StrComp(Extension, ".bmp", CompareMethod.Text) = 0 Or _
                   StrComp(Extension, ".jpg", CompareMethod.Text) = 0 Or _
                   StrComp(Extension, ".jpeg", CompareMethod.Text) = 0 Or _
                   StrComp(Extension, ".png", CompareMethod.Text) = 0 Or _
                   StrComp(Extension, ".pdf", CompareMethod.Text) = 0 Or _
                   StrComp(Extension, ".tif", CompareMethod.Text) = 0 Then
            WebBrowser1.Navigate(tFilePath.Text)
        ElseIf StrComp(Extension, ".cdr", CompareMethod.Text) = 0 Or _
            StrComp(Extension, ".cmx", CompareMethod.Text) = 0 Or _
            StrComp(Extension, ".cdt", CompareMethod.Text) = 0 Then
            'Dim vbres As MsgBoxResult
            'vbres = MsgBox("Document type is a CorelDraw graphic file format. Do you want to open the file using an external viewer?", vbYesNo, "TSD Inventory System")
            'If vbres = vbYes Then
            '    Process.Start(tFilePath.Text)
            'End If
        ElseIf StrComp(Extension, ".xcf", CompareMethod.Text) = 0 Then
            Dim vbres As MsgBoxResult
            vbres = MsgBox("Document type is a GIMP graphic file format. Do you want to open the file using GIMP?", vbYesNo, "TSD Inventory System")
            If vbres = vbYes Then
                Process.Start(tFilePath.Text)
            End If
        ElseIf StrComp(Extension, ".ai", CompareMethod.Text) = 0 Then
            Dim vbres As MsgBoxResult
            vbres = MsgBox("Document type is an Adobe Illustrator file format. Do you want to open the file using Adobe Illustrator?", vbYesNo, "TSD Inventory System")
            If vbres = vbYes Then
                Process.Start(tFilePath.Text)
            End If
        ElseIf StrComp(Extension, ".psd", CompareMethod.Text) = 0 Then
            Dim vbres As MsgBoxResult
            vbres = MsgBox("Document type is an Adobe Photoshop file format. Do you want to open the file using Adobe Illustrator?", vbYesNo, "TSD Inventory System")
            If vbres = vbYes Then
                Me.Cursor = Cursors.WaitCursor
                Process.Start(tFilePath.Text)
                Me.Cursor = Cursors.Default
            End If
        Else
            MsgBox("Unknown file format!", MsgBoxStyle.Exclamation, "TSD Inventory System")
        End If
    End Sub
    Private Sub BrowseCustomerFile()
        UploadPrintcardFile.Filter = "Portable Document Format(PDF) File (*.pdf)|*.pdf;|" & _
                                   "CorelDraw Graphic Files(CDR) Files (*.cdr,*.cdt,*.cmx)|*.cdr;*.cdt;*.cmx;|" & _
                                   "Corel Photopaint (*.cpt)|*.cpt;|" & _
                                   "Adobe Illustrator (*.ai)|*.ai;|" & _
                                   "Adobe Photoshop (*.psd)|*.psd;|" & _
                                   "GIMP (*.xcf)|*.xcf;|" & _
                                   "Image Files (*.bmp, *.jpg, *.jpeg, *.tif)|*.bmp;*.jpg;*.jpeg;*.tif;"
        UploadPrintcardFile.FileName = ""
        UploadPrintcardFile.ShowDialog()
        tCustomerFile.Text = UploadPrintcardFile.FileName
    End Sub
    Private Sub cmbJoint_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbJoint.SelectedIndexChanged
        JointID = objCustomer.GetJointID(cmbJoint.Text)
        SetFactorValues()
        ComputeBoxSize()
    End Sub

    Private Sub tLength_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tLength.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tWidth_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tWidth.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tFlap_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub
    Public Sub ResetForm()
        tBoxDescription.Text = ""
        tLength.Text = ""
        tWidth.Text = ""
        tHeight.Text = ""
        cmbBoardType.ResetText()
        tPaperCombination.Text = ""
        tOuterLiner.Text = ""
        tColor1.Text = "N/A"
        tColor2.Text = "N/A"
        tColor3.Text = "N/A"
        tColor4.Text = "N/A"
        tPrintcardNumber.Text = ""
        tFilePath.Text = ""
        tPrintcardNotes.Text = ""        
        tPanel1.Text = ""
        tPanel2.Text = ""
        tPanel3.Text = ""
        tPanel4.Text = ""
        tBoardLength.Text = ""
        tBoardWidth.Text = ""
        tBoxHeight.Text = ""
        tFlap.Text = ""
        tCustomerFile.Text = ""
        tFilePath.Text = ""

    End Sub

    Private Sub tColor1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tColor1.GotFocus, tColor2.GotFocus, tColor3.GotFocus, tColor4.GotFocus
        If tColor1.Focused Then tColor1.SelectAll()
        If tColor2.Focused Then tColor2.SelectAll()
        If tColor3.Focused Then tColor3.SelectAll()
        If tColor4.Focused Then tColor4.SelectAll()
    End Sub

    Private Sub tPrintcardNotes_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tPrintcardNotes.GotFocus
        tPrintcardNotes.SelectAll()
    End Sub

    Private Sub tPrintcardNotes_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tPrintcardNotes.TextChanged
        If tPrintcardNotes.TextLength > 255 Then
            SendKeys.Send(ControlChars.Back)
        End If
        MainUI.StatusMessage.Text = NotesCharCount - tPrintcardNotes.TextLength & " Chars left."
    End Sub

    Private Sub tColor1_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tColor1.LostFocus
        If tColor1.Text = "" Then
            tColor1.Text = "N/A"
        End If
    End Sub

    Private Sub tColor2_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tColor2.LostFocus
        If tColor2.Text = "" Then
            tColor2.Text = "N/A"
        End If
    End Sub

    Private Sub tColor3_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tColor3.LostFocus
        If tColor3.Text = "" Then
            tColor3.Text = "N/A"
        End If
    End Sub

    Private Sub tColor4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tColor4.TextChanged
        If tColor4.Text = "" Then
            tColor4.Text = "N/A"
        End If
    End Sub

    Private Sub tGlueTab_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tGlueTab.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub


    Private Sub tPanel1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tPanel1.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tPanel2_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tPanel2.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tPanel3_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tPanel3.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tPanel4_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tPanel4.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tBoardLength_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tBoardLength.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tBoardWidth_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tBoardWidth.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tBoxHeight_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tBoxHeight.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub tFlap_KeyPress_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tFlap.KeyPress
        Dim allowedChars As String = "1234567890." & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub theight_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tHeight.TextChanged
        ComputeBoxSize()
    End Sub
    Public Sub ComputeBoxSize()
        If tLength.Text <> "" And tWidth.Text <> "" And tHeight.Text <> "" And tGlueTab.Text <> "" Then
            GlueTab = tGlueTab.Text
            Panel1 = tLength.Text + factor1
            Panel2 = tWidth.Text + factor2
            Panel3 = tLength.Text + factor3
            Panel4 = tWidth.Text + factor4
            BoxHeight = tHeight.Text + FactorHeight
            BoxFlap = (tWidth.Text / 2) + FactorFlap

            BoardLength = GlueTab + (Panel1 + Panel2 + Panel3 + Panel4)
            If BoxFormatType = "Regular Slotted Container" Then
                BoardWidth = (BoxFlap * 2) + BoxHeight
            Else
                BoardWidth = BoxFlap + BoxHeight
            End If
            tPanel1.Text = Panel1
            tPanel2.Text = Panel2
            tPanel3.Text = Panel3
            tPanel4.Text = Panel4
            tBoardLength.Text = BoardLength
            tBoardWidth.Text = BoardWidth
            tFlap.Text = BoxFlap
            tBoxHeight.Text = BoxHeight
        End If

    End Sub

    Private Sub SetFactorValues()
        Dim objBoxCompute As classCorrugatedBox = New classCorrugatedBox
        factor1 = objBoxCompute.ComputeBoxSize(cBoardTypeID, JointID, BoxFormatID, tGlueTab.Text).factor1
        factor2 = objBoxCompute.ComputeBoxSize(cBoardTypeID, JointID, BoxFormatID, tGlueTab.Text).factor2
        factor3 = objBoxCompute.ComputeBoxSize(cBoardTypeID, JointID, BoxFormatID, tGlueTab.Text).factor3
        factor4 = objBoxCompute.ComputeBoxSize(cBoardTypeID, JointID, BoxFormatID, tGlueTab.Text).factor4
        FactorFlap = objBoxCompute.ComputeBoxSize(cBoardTypeID, JointID, BoxFormatID, tGlueTab.Text).FactorFlap
        FactorHeight = objBoxCompute.ComputeBoxSize(cBoardTypeID, JointID, BoxFormatID, tGlueTab.Text).FactorHeight
        BoxFormatType = objBoxCompute.ComputeBoxSize(cBoardTypeID, JointID, BoxFormatID, tGlueTab.Text).BoxFormat
        objBoxCompute = Nothing
    End Sub

    Private Sub tLength_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tLength.TextChanged
        ComputeBoxSize()
    End Sub

    Private Sub tWidth_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tWidth.TextChanged
        ComputeBoxSize()
    End Sub

    Private Sub tGlueTab_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tGlueTab.LostFocus
        If tGlueTab.Text <> "" Then
            If tGlueTab.Text < 20 Then 'TODO: Get value from database
                tGlueTab.Text = 35
            End If
        Else
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tGlueTab_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tGlueTab.TextChanged
        If tGlueTab.Text <> "" Then
            ' Set the BoardLength value again to make it accurate, because editing panels will not change BoardLength value
            ' that was set earlier in ComputeBoxSize() procedure.
            GlueTab = tGlueTab.Text 'Set GlueTab to the tGlueTab's new value
            BoardLength = GlueTab + (Panel1 + Panel2 + Panel3 + Panel4) ' Compute BoardLength again
            tBoardLength.Text = (BoardLength - GlueTab) + tGlueTab.Text ' Then add and display the correct value according to the changes made in the panels
        Else 'The user leaves the panel empty, so it is safe to compute and restore the default values
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tBoxHeight_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tBoxHeight.LostFocus
        If tBoxHeight.Text <> "" Then
            If tBoxHeight.Text < tHeight.Text Then
                ComputeBoxSize()
            End If
        Else
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tBoxHeight_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tBoxHeight.TextChanged
        If tBoxHeight.Text <> "" Then
            BoxHeight = tBoxHeight.Text
            If BoxFormatType = "Regular Slotted Container" Then
                BoardWidth = (BoxFlap * 2) + BoxHeight
            Else
                BoardWidth = BoxFlap + BoxHeight
            End If
            tBoardWidth.Text = (BoardWidth - BoxHeight) + tBoxHeight.Text
        Else
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tFlap_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tFlap.TextChanged
        If tFlap.Text <> "" Then
            BoxFlap = tFlap.Text
            If BoxFormatType = "Regular Slotted Container" Then
                BoardWidth = (BoxFlap * 2) + BoxHeight
            Else
                BoardWidth = BoxFlap + BoxHeight
            End If
            tBoardWidth.Text = (BoardWidth - BoxFlap) + tFlap.Text
        Else
            ComputeBoxSize()
        End If

    End Sub

    Private Sub tPanel1_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tPanel1.LostFocus
        If tPanel1.Text < tLength.Text Then
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tPanel1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tPanel1.TextChanged
        If tPanel1.Text <> "" Then
            ' Set the BoardLength value again to make it accurate, because editing panels will not change BoardLength value
            ' that was set earlier in ComputeBoxSize() procedure.
            Panel1 = tPanel1.Text 'Set Panel1 to the tPanel1's new value
            BoardLength = GlueTab + (Panel1 + Panel2 + Panel3 + Panel4) ' Compute BoardLength again
            tBoardLength.Text = (BoardLength - Panel1) + tPanel1.Text ' Then add and display the correct value according to the changes made in the panels
        Else 'The user leaves the panel empty, so it is safe to compute and restore the default values
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tPanel2_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tPanel2.LostFocus
        If tPanel2.Text <> "" Then
            If tPanel2.Text < tWidth.Text Then
                ComputeBoxSize()
            End If
        Else
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tPanel2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tPanel2.TextChanged
        If tPanel2.Text <> "" Then
            ' Set the BoardLength value again to make it accurate, because editing panels will not change BoardLength value
            ' that was set earlier in ComputeBoxSize() procedure.
            Panel2 = tPanel2.Text 'Set Panel2 to the tPanel2's new value
            BoardLength = GlueTab + (Panel1 + Panel2 + Panel3 + Panel4) ' Compute BoardLength again
            tBoardLength.Text = (BoardLength - Panel2) + tPanel2.Text ' Then add and display the correct value according to the changes made in the panels
        Else 'The user leaves the panel empty, so it is safe to compute and restore the default values
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tPanel3_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tPanel3.LostFocus
        If tPanel3.Text <> "" Then
            If tPanel3.Text < tLength.Text Then
                ComputeBoxSize()
            End If
        Else
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tPanel3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tPanel3.TextChanged
        If tPanel3.Text <> "" Then
            ' Set the BoardLength value again to make it accurate, because editing panels will not change BoardLength value
            ' that was set earlier in ComputeBoxSize() procedure.
            Panel3 = tPanel3.Text 'Set Panel3 to the tPanel3's new value
            BoardLength = GlueTab + (Panel1 + Panel2 + Panel3 + Panel4) ' Compute BoardLength again
            tBoardLength.Text = (BoardLength - Panel3) + tPanel3.Text ' Then add and display the correct value according to the changes made in the panels
        Else 'The user leaves the panel empty, so it is safe to compute and restore the default values
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tPanel4_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles tPanel4.LostFocus
        If tPanel4.Text <> "" Then
            If tPanel4.Text < tWidth.Text Then
                ComputeBoxSize()
            End If
        Else
            ComputeBoxSize()
        End If
        
    End Sub

    Private Sub tPanel4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tPanel4.TextChanged
        If tPanel4.Text <> "" Then
            ' Set the BoardLength value again to make it accurate, because editing panels will not change BoardLength value
            ' that was set earlier in ComputeBoxSize() procedure.
            Panel4 = tPanel4.Text 'Set Panel3 to the tPanel4's new value
            BoardLength = GlueTab + (Panel1 + Panel2 + Panel3 + Panel4) ' Compute BoardLength again
            tBoardLength.Text = (BoardLength - Panel4) + tPanel4.Text ' Then add and display the correct value according to the changes made in the panels
        Else 'The user leaves the panel empty, so it is safe to compute and restore the default values
            ComputeBoxSize()
        End If
    End Sub

    Private Sub tFilePath_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tFilePath.Click
        BrowseFile()
    End Sub

    Private Sub tCustomerFile_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles tCustomerFile.Click
        BrowseCustomerFile()
    End Sub

    Private Sub cmdBrowseCustFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBrowseCustFile.Click
        BrowseCustomerFile()
    End Sub

    Private Sub tCustomerName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tCustomerName.TextChanged
        Dim IndustryType As Short = objCustomer.GetIndustryType(customer_id)
        If IndustryType = 1 Then ' Banana, then set to Half Slotted Container
            cmbBoxFormat.Text = "Half Slotted Container"
        ElseIf IndustryType > 1 Then
            cmbBoxFormat.Text = "Regular Slotted Container"
        End If
    End Sub

    Private Sub tPrintcardNumber_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles tPrintcardNumber.KeyPress
        Dim allowedChars As String = "1234567890" & ControlChars.Back
        If allowedChars.IndexOf(e.KeyChar) = -1 Then
            e.Handled = True
        End If
    End Sub

End Class