﻿Imports Npgsql
Public Class DataConnection
    Public dbHost As String = "192.168.2.7"
    Public dbName As String = "tsd_inventory"
    Public dbUser As String = "tsd"
    Public dbPassword As String = "3137Y6s"
    Public dbPooling As Boolean = True
    Public cmd As NpgsqlCommand
    Public sql As String
    Public dr As NpgsqlDataReader
    Public da As NpgsqlDataAdapter
    Public ds As New DataSet
    Public conn As New NpgsqlConnection("SERVER=" & dbHost & ";DATABASE=" & dbName & ";USER ID=" & dbUser & ";PASSWORD=" & dbPassword & ";pooling=" & dbPooling & "; port=5432")
End Class
