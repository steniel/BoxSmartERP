﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BrowsePrintcard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PrintcardGrid = New System.Windows.Forms.DataGridView()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdCreateCopy = New System.Windows.Forms.Button()
        Me.cSearchThis = New System.Windows.Forms.TextBox()
        Me.cmdViewPrintcard = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbMonth = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.cmbNumRecords = New System.Windows.Forms.ComboBox()
        Me.gridColumn = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmdSearch = New System.Windows.Forms.Button()
        Me.lCountRows = New System.Windows.Forms.Label()
        Me.lCurrentSel = New System.Windows.Forms.Label()
        Me.cmdRefresh = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.cmdSearchDB = New System.Windows.Forms.Button()
        Me.cmdViewCustomerFile = New System.Windows.Forms.Button()
        Me.fileid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.organization_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.box_description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.insidedimension = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.boardlength = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.filename = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.printcardno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.diecut_number = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.racklocation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.date_created = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.filetype = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.color1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.color2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.color3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.color4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.boardtypeid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.fluteid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.testid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.jointid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.combinationid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dimensionid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.scaleid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.customer_file_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.customerfile = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.customerfiletype = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.printcopyno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.PrintcardGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PrintcardGrid
        '
        Me.PrintcardGrid.AllowUserToAddRows = False
        Me.PrintcardGrid.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.PrintcardGrid.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.PrintcardGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PrintcardGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.fileid, Me.id, Me.organization_name, Me.box_description, Me.insidedimension, Me.boardlength, Me.filename, Me.printcardno, Me.diecut_number, Me.racklocation, Me.date_created, Me.filetype, Me.color1, Me.color2, Me.color3, Me.color4, Me.boardtypeid, Me.fluteid, Me.testid, Me.jointid, Me.combinationid, Me.dimensionid, Me.scaleid, Me.customer_file_id, Me.customerfile, Me.customerfiletype, Me.printcopyno})
        Me.PrintcardGrid.Location = New System.Drawing.Point(15, 50)
        Me.PrintcardGrid.Margin = New System.Windows.Forms.Padding(4)
        Me.PrintcardGrid.MultiSelect = False
        Me.PrintcardGrid.Name = "PrintcardGrid"
        Me.PrintcardGrid.ReadOnly = True
        Me.PrintcardGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.PrintcardGrid.Size = New System.Drawing.Size(1207, 488)
        Me.PrintcardGrid.TabIndex = 0
        '
        'cmdCancel
        '
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.Location = New System.Drawing.Point(15, 546)
        Me.cmdCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(113, 48)
        Me.cmdCancel.TabIndex = 40
        Me.cmdCancel.Text = "Close"
        Me.cmdCancel.UseVisualStyleBackColor = True
        '
        'cmdCreateCopy
        '
        Me.cmdCreateCopy.Location = New System.Drawing.Point(1109, 546)
        Me.cmdCreateCopy.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdCreateCopy.Name = "cmdCreateCopy"
        Me.cmdCreateCopy.Size = New System.Drawing.Size(113, 48)
        Me.cmdCreateCopy.TabIndex = 30
        Me.cmdCreateCopy.Text = "Create Copy"
        Me.cmdCreateCopy.UseVisualStyleBackColor = True
        '
        'cSearchThis
        '
        Me.cSearchThis.Location = New System.Drawing.Point(320, 7)
        Me.cSearchThis.Name = "cSearchThis"
        Me.cSearchThis.Size = New System.Drawing.Size(250, 22)
        Me.cSearchThis.TabIndex = 10
        '
        'cmdViewPrintcard
        '
        Me.cmdViewPrintcard.Location = New System.Drawing.Point(988, 546)
        Me.cmdViewPrintcard.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdViewPrintcard.Name = "cmdViewPrintcard"
        Me.cmdViewPrintcard.Size = New System.Drawing.Size(113, 48)
        Me.cmdViewPrintcard.TabIndex = 25
        Me.cmdViewPrintcard.Text = "View Printcard"
        Me.cmdViewPrintcard.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(757, 11)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 16)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Limit results:"
        '
        'cmbMonth
        '
        Me.cmbMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMonth.FormattingEnabled = True
        Me.cmbMonth.Items.AddRange(New Object() {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", "All Year Round"})
        Me.cmbMonth.Location = New System.Drawing.Point(965, 7)
        Me.cmbMonth.Name = "cmbMonth"
        Me.cmbMonth.Size = New System.Drawing.Size(135, 24)
        Me.cmbMonth.TabIndex = 32
        Me.cmbMonth.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(912, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 16)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Month:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(1110, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 16)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Year:"
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(1156, 8)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(66, 22)
        Me.txtYear.TabIndex = 33
        Me.txtYear.TabStop = False
        '
        'cmbNumRecords
        '
        Me.cmbNumRecords.FormattingEnabled = True
        Me.cmbNumRecords.Items.AddRange(New Object() {"10", "20", "30", "40", "50", "100", "150", "200", "250", "300", "350", "400", "450", "500", "600", "700", "800", "900", "1000", "1200", "1300", "1400", "1500", "1600", "1700", "1800", "1900", "2000"})
        Me.cmbNumRecords.Location = New System.Drawing.Point(843, 7)
        Me.cmbNumRecords.Name = "cmbNumRecords"
        Me.cmbNumRecords.Size = New System.Drawing.Size(63, 24)
        Me.cmbNumRecords.TabIndex = 34
        Me.cmbNumRecords.TabStop = False
        '
        'gridColumn
        '
        Me.gridColumn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.gridColumn.FormattingEnabled = True
        Me.gridColumn.Location = New System.Drawing.Point(91, 6)
        Me.gridColumn.Name = "gridColumn"
        Me.gridColumn.Size = New System.Drawing.Size(122, 24)
        Me.gridColumn.TabIndex = 35
        Me.gridColumn.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 10)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 16)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Search by:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(219, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 16)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "Text to search:"
        '
        'cmdSearch
        '
        Me.cmdSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSearch.Location = New System.Drawing.Point(585, 4)
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.Size = New System.Drawing.Size(74, 39)
        Me.cmdSearch.TabIndex = 36
        Me.cmdSearch.Text = "Search Row"
        Me.cmdSearch.UseVisualStyleBackColor = True
        '
        'lCountRows
        '
        Me.lCountRows.AutoSize = True
        Me.lCountRows.Location = New System.Drawing.Point(326, 546)
        Me.lCountRows.Name = "lCountRows"
        Me.lCountRows.Size = New System.Drawing.Size(49, 16)
        Me.lCountRows.TabIndex = 37
        Me.lCountRows.Text = "Label1"
        '
        'lCurrentSel
        '
        Me.lCurrentSel.AutoSize = True
        Me.lCurrentSel.Location = New System.Drawing.Point(326, 578)
        Me.lCurrentSel.Name = "lCurrentSel"
        Me.lCurrentSel.Size = New System.Drawing.Size(49, 16)
        Me.lCurrentSel.TabIndex = 37
        Me.lCurrentSel.Text = "Label1"
        '
        'cmdRefresh
        '
        Me.cmdRefresh.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdRefresh.Location = New System.Drawing.Point(136, 546)
        Me.cmdRefresh.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdRefresh.Name = "cmdRefresh"
        Me.cmdRefresh.Size = New System.Drawing.Size(113, 48)
        Me.cmdRefresh.TabIndex = 35
        Me.cmdRefresh.Text = "Refresh"
        Me.cmdRefresh.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 360000
        '
        'cmdSearchDB
        '
        Me.cmdSearchDB.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSearchDB.Location = New System.Drawing.Point(665, 4)
        Me.cmdSearchDB.Name = "cmdSearchDB"
        Me.cmdSearchDB.Size = New System.Drawing.Size(74, 39)
        Me.cmdSearchDB.TabIndex = 36
        Me.cmdSearchDB.Text = "Search Database"
        Me.cmdSearchDB.UseVisualStyleBackColor = True
        '
        'cmdViewCustomerFile
        '
        Me.cmdViewCustomerFile.Location = New System.Drawing.Point(867, 546)
        Me.cmdViewCustomerFile.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdViewCustomerFile.Name = "cmdViewCustomerFile"
        Me.cmdViewCustomerFile.Size = New System.Drawing.Size(113, 48)
        Me.cmdViewCustomerFile.TabIndex = 20
        Me.cmdViewCustomerFile.Text = "View Customer File"
        Me.cmdViewCustomerFile.UseVisualStyleBackColor = True
        '
        'fileid
        '
        Me.fileid.DataPropertyName = "fileid"
        Me.fileid.HeaderText = "File ID"
        Me.fileid.Name = "fileid"
        Me.fileid.ReadOnly = True
        Me.fileid.Visible = False
        '
        'id
        '
        Me.id.DataPropertyName = "id"
        Me.id.HeaderText = "ID"
        Me.id.Name = "id"
        Me.id.ReadOnly = True
        Me.id.Width = 50
        '
        'organization_name
        '
        Me.organization_name.DataPropertyName = "organization_name"
        Me.organization_name.HeaderText = "Customer"
        Me.organization_name.Name = "organization_name"
        Me.organization_name.ReadOnly = True
        Me.organization_name.Width = 200
        '
        'box_description
        '
        Me.box_description.DataPropertyName = "box_description"
        Me.box_description.HeaderText = "Box Description"
        Me.box_description.Name = "box_description"
        Me.box_description.ReadOnly = True
        Me.box_description.Width = 300
        '
        'insidedimension
        '
        Me.insidedimension.DataPropertyName = "insidedimension"
        Me.insidedimension.HeaderText = "Inside Dimension"
        Me.insidedimension.Name = "insidedimension"
        Me.insidedimension.ReadOnly = True
        '
        'boardlength
        '
        Me.boardlength.DataPropertyName = "boardsize"
        Me.boardlength.HeaderText = "Board Size"
        Me.boardlength.Name = "boardlength"
        Me.boardlength.ReadOnly = True
        Me.boardlength.Width = 130
        '
        'filename
        '
        Me.filename.DataPropertyName = "filename"
        Me.filename.HeaderText = "Filename"
        Me.filename.Name = "filename"
        Me.filename.ReadOnly = True
        Me.filename.Width = 200
        '
        'printcardno
        '
        Me.printcardno.DataPropertyName = "printcardno"
        Me.printcardno.HeaderText = "Printcard No."
        Me.printcardno.Name = "printcardno"
        Me.printcardno.ReadOnly = True
        Me.printcardno.Width = 150
        '
        'diecut_number
        '
        Me.diecut_number.DataPropertyName = "diecut_number"
        Me.diecut_number.HeaderText = "Diecut #"
        Me.diecut_number.Name = "diecut_number"
        Me.diecut_number.ReadOnly = True
        '
        'racklocation
        '
        Me.racklocation.DataPropertyName = "racklocation"
        Me.racklocation.HeaderText = "Rack Location"
        Me.racklocation.Name = "racklocation"
        Me.racklocation.ReadOnly = True
        Me.racklocation.Width = 75
        '
        'date_created
        '
        Me.date_created.DataPropertyName = "date_created"
        Me.date_created.HeaderText = "Date Created"
        Me.date_created.Name = "date_created"
        Me.date_created.ReadOnly = True
        Me.date_created.Width = 150
        '
        'filetype
        '
        Me.filetype.DataPropertyName = "filetype"
        Me.filetype.HeaderText = "Filetype"
        Me.filetype.Name = "filetype"
        Me.filetype.ReadOnly = True
        Me.filetype.Visible = False
        Me.filetype.Width = 120
        '
        'color1
        '
        Me.color1.DataPropertyName = "color1"
        Me.color1.HeaderText = "Color 1"
        Me.color1.Name = "color1"
        Me.color1.ReadOnly = True
        Me.color1.Visible = False
        '
        'color2
        '
        Me.color2.DataPropertyName = "color2"
        Me.color2.HeaderText = "Color 2"
        Me.color2.Name = "color2"
        Me.color2.ReadOnly = True
        Me.color2.Visible = False
        '
        'color3
        '
        Me.color3.DataPropertyName = "color3"
        Me.color3.HeaderText = "Color 3"
        Me.color3.Name = "color3"
        Me.color3.ReadOnly = True
        Me.color3.Visible = False
        '
        'color4
        '
        Me.color4.DataPropertyName = "color4"
        Me.color4.HeaderText = "Color 4"
        Me.color4.Name = "color4"
        Me.color4.ReadOnly = True
        Me.color4.Visible = False
        '
        'boardtypeid
        '
        Me.boardtypeid.DataPropertyName = "boardtypeid"
        Me.boardtypeid.HeaderText = "Board Type"
        Me.boardtypeid.Name = "boardtypeid"
        Me.boardtypeid.ReadOnly = True
        Me.boardtypeid.Visible = False
        '
        'fluteid
        '
        Me.fluteid.DataPropertyName = "fluteid"
        Me.fluteid.HeaderText = "Flute ID"
        Me.fluteid.Name = "fluteid"
        Me.fluteid.ReadOnly = True
        Me.fluteid.Visible = False
        '
        'testid
        '
        Me.testid.DataPropertyName = "testid"
        Me.testid.HeaderText = "Test"
        Me.testid.Name = "testid"
        Me.testid.ReadOnly = True
        Me.testid.Visible = False
        '
        'jointid
        '
        Me.jointid.DataPropertyName = "jointid"
        Me.jointid.HeaderText = "Joint"
        Me.jointid.Name = "jointid"
        Me.jointid.ReadOnly = True
        Me.jointid.Visible = False
        '
        'combinationid
        '
        Me.combinationid.DataPropertyName = "combinationid"
        Me.combinationid.HeaderText = "Combination"
        Me.combinationid.Name = "combinationid"
        Me.combinationid.ReadOnly = True
        Me.combinationid.Visible = False
        '
        'dimensionid
        '
        Me.dimensionid.DataPropertyName = "dimensionid"
        Me.dimensionid.HeaderText = "Dimension"
        Me.dimensionid.Name = "dimensionid"
        Me.dimensionid.ReadOnly = True
        Me.dimensionid.Visible = False
        '
        'scaleid
        '
        Me.scaleid.DataPropertyName = "scaleid"
        Me.scaleid.HeaderText = "Scale"
        Me.scaleid.Name = "scaleid"
        Me.scaleid.ReadOnly = True
        Me.scaleid.Visible = False
        '
        'customer_file_id
        '
        Me.customer_file_id.DataPropertyName = "customer_file_id"
        Me.customer_file_id.HeaderText = "Customer File ID"
        Me.customer_file_id.Name = "customer_file_id"
        Me.customer_file_id.ReadOnly = True
        Me.customer_file_id.Visible = False
        '
        'customerfile
        '
        Me.customerfile.DataPropertyName = "customerfile"
        Me.customerfile.HeaderText = "Customer File"
        Me.customerfile.Name = "customerfile"
        Me.customerfile.ReadOnly = True
        Me.customerfile.Visible = False
        '
        'customerfiletype
        '
        Me.customerfiletype.DataPropertyName = "customerfiletype"
        Me.customerfiletype.HeaderText = "CustomerFileType"
        Me.customerfiletype.Name = "customerfiletype"
        Me.customerfiletype.ReadOnly = True
        Me.customerfiletype.Visible = False
        '
        'printcopyno
        '
        Me.printcopyno.DataPropertyName = "printcopyno"
        Me.printcopyno.HeaderText = "Printcard #"
        Me.printcopyno.Name = "printcopyno"
        Me.printcopyno.ReadOnly = True
        '
        'BrowsePrintcard
        '
        Me.AcceptButton = Me.cmdSearch
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1235, 610)
        Me.Controls.Add(Me.lCurrentSel)
        Me.Controls.Add(Me.lCountRows)
        Me.Controls.Add(Me.cmdSearchDB)
        Me.Controls.Add(Me.cmdSearch)
        Me.Controls.Add(Me.gridColumn)
        Me.Controls.Add(Me.cmbNumRecords)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.cmbMonth)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cSearchThis)
        Me.Controls.Add(Me.cmdViewCustomerFile)
        Me.Controls.Add(Me.cmdViewPrintcard)
        Me.Controls.Add(Me.cmdCreateCopy)
        Me.Controls.Add(Me.cmdRefresh)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.PrintcardGrid)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "BrowsePrintcard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Browse Printcard"
        CType(Me.PrintcardGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PrintcardGrid As System.Windows.Forms.DataGridView
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdCreateCopy As System.Windows.Forms.Button
    Friend WithEvents cSearchThis As System.Windows.Forms.TextBox
    Friend WithEvents cmdViewPrintcard As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbMonth As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtYear As System.Windows.Forms.TextBox
    Friend WithEvents cmbNumRecords As System.Windows.Forms.ComboBox
    Friend WithEvents gridColumn As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cmdSearch As System.Windows.Forms.Button
    Friend WithEvents lCountRows As System.Windows.Forms.Label
    Friend WithEvents lCurrentSel As System.Windows.Forms.Label
    Friend WithEvents cmdRefresh As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents cmdSearchDB As System.Windows.Forms.Button
    Friend WithEvents cmdViewCustomerFile As System.Windows.Forms.Button
    Friend WithEvents fileid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents organization_name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents box_description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents insidedimension As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents boardlength As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents filename As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents printcardno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents diecut_number As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents racklocation As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents date_created As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents filetype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents color1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents color2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents color3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents color4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents boardtypeid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents fluteid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents testid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents jointid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents combinationid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dimensionid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents scaleid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents customer_file_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents customerfile As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents customerfiletype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents printcopyno As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
