﻿Public Class FilePreview

    Private Sub FilePreview_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.MdiParent = MainUI

    End Sub
End Class