﻿Public Class GetCombination
    Dim objGetCombination As Customer
    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Dim PaperCombStr As String = ""
        For Each CombinationList In Me.gridPaperCombination.SelectedRows
            Dim strOuterColor As String = CombinationList.cells("outerliner").value            
            PrintCard.PaperCombinationID = CombinationList.cells("id").value
            If PrintCard.cmbBoardType.Text = "CB-Flute" Then
                PaperCombStr = CombinationList.cells("outerliner").value & " X " & _
                           CombinationList.cells("mid_liner").value & " X " & _
                           CombinationList.cells("mid_liner2").value & " X " & _
                           CombinationList.cells("mid_liner3").value & " X " & _
                           CombinationList.cells("InnerLiner").value
            Else
                PaperCombStr = CombinationList.cells("outerliner").value & " X " & _
                           CombinationList.cells("mid_liner").value & " X " & _
                           CombinationList.cells("InnerLiner").value
            End If
            
            'Put Brown or White in that textbox
            If strOuterColor.Contains("WKL") Then
                PrintCard.tOuterLiner.Text = "White"
            Else 'Then it is brown
                PrintCard.tOuterLiner.Text = "Brown"
            End If
        Next

        PrintCard.tPaperCombination.Text = PaperCombStr

        Me.Close()
    End Sub

    Private Sub GetCombination_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        objGetCombination = Nothing
    End Sub

    Private Sub GetCombination_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        objGetCombination = New Customer        
        objGetCombination.GetPaperCombination(Me.gridPaperCombination, PrintCard.cmbBoardType.Text)
        If gridPaperCombination.RowCount = 0 Then
            MsgBox("No paper combination for type: " & PrintCard.cmbBoardType.Text & ", please add paper combinations of this type.", MsgBoxStyle.Critical, "TSD Inventory")
            PrintCard.cmbBoardType.Text = PrintCard.PreviousFlute
            Me.Close()
        End If
    End Sub
End Class