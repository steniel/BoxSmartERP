﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PrintCard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.tCustomerName = New System.Windows.Forms.TextBox()
        Me.tBoxDescription = New System.Windows.Forms.TextBox()
        Me.tLength = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.cPrintcardCreated = New System.Windows.Forms.DateTimePicker()
        Me.lDiecut = New System.Windows.Forms.Label()
        Me.lDimensionID = New System.Windows.Forms.Label()
        Me.cmbDiecut = New System.Windows.Forms.ComboBox()
        Me.cmbScale = New System.Windows.Forms.ComboBox()
        Me.cmbUnits = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.cmbJoint = New System.Windows.Forms.ComboBox()
        Me.cmbBoxFormat = New System.Windows.Forms.ComboBox()
        Me.PSI_id = New System.Windows.Forms.Label()
        Me.tWidth = New System.Windows.Forms.TextBox()
        Me.boardID = New System.Windows.Forms.Label()
        Me.cmbPSI = New System.Windows.Forms.ComboBox()
        Me.cmbBoardType = New System.Windows.Forms.ComboBox()
        Me.cmdGetCombination = New System.Windows.Forms.Button()
        Me.cmdCompute = New System.Windows.Forms.Button()
        Me.GetCustomer = New System.Windows.Forms.Button()
        Me.tColor4 = New System.Windows.Forms.TextBox()
        Me.tHeight = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tColor3 = New System.Windows.Forms.TextBox()
        Me.tOuterLiner = New System.Windows.Forms.TextBox()
        Me.tPaperCombination = New System.Windows.Forms.TextBox()
        Me.tPrintcardNumber = New System.Windows.Forms.TextBox()
        Me.tPrincardPrefix = New System.Windows.Forms.TextBox()
        Me.tColor2 = New System.Windows.Forms.TextBox()
        Me.tColor1 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lScaleID = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lBoxFormatId = New System.Windows.Forms.Label()
        Me.lUnitID = New System.Windows.Forms.Label()
        Me.UploadPrintcardFile = New System.Windows.Forms.OpenFileDialog()
        Me.cmdBrowseFile = New System.Windows.Forms.Button()
        Me.tFilePath = New System.Windows.Forms.TextBox()
        Me.tPrintcardNotes = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.tCustomerFile = New System.Windows.Forms.TextBox()
        Me.cmdBrowseCustFile = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.tPanel4 = New System.Windows.Forms.TextBox()
        Me.tPanel3 = New System.Windows.Forms.TextBox()
        Me.tPanel2 = New System.Windows.Forms.TextBox()
        Me.tPanel1 = New System.Windows.Forms.TextBox()
        Me.tGlueTab = New System.Windows.Forms.TextBox()
        Me.tBoardWidth = New System.Windows.Forms.TextBox()
        Me.tBoardLength = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.tFlap = New System.Windows.Forms.TextBox()
        Me.tBoxHeight = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 25)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Customer Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(10, 55)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 16)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Box Description:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(36, 86)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 16)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Box Format:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(49, 118)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 16)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "I.D.: / Unit:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(769, 25)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 16)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Color 1:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(769, 55)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 16)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Color 2:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(769, 86)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(53, 16)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Color 3:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(769, 114)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 16)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Color 4:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(971, 25)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 16)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Scale Factor:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(984, 55)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(74, 16)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Printcard #:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(999, 86)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(59, 16)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "Diecut #:"
        '
        'tCustomerName
        '
        Me.tCustomerName.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.tCustomerName.Location = New System.Drawing.Point(119, 22)
        Me.tCustomerName.Name = "tCustomerName"
        Me.tCustomerName.ReadOnly = True
        Me.tCustomerName.Size = New System.Drawing.Size(288, 22)
        Me.tCustomerName.TabIndex = 1
        Me.tCustomerName.TabStop = False
        '
        'tBoxDescription
        '
        Me.tBoxDescription.Location = New System.Drawing.Point(119, 52)
        Me.tBoxDescription.Name = "tBoxDescription"
        Me.tBoxDescription.Size = New System.Drawing.Size(288, 22)
        Me.tBoxDescription.TabIndex = 10
        '
        'tLength
        '
        Me.tLength.Location = New System.Drawing.Point(119, 115)
        Me.tLength.Name = "tLength"
        Me.tLength.Size = New System.Drawing.Size(55, 22)
        Me.tLength.TabIndex = 30
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.cPrintcardCreated)
        Me.GroupBox1.Controls.Add(Me.lDiecut)
        Me.GroupBox1.Controls.Add(Me.lDimensionID)
        Me.GroupBox1.Controls.Add(Me.cmbDiecut)
        Me.GroupBox1.Controls.Add(Me.cmbScale)
        Me.GroupBox1.Controls.Add(Me.cmbUnits)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.cmbJoint)
        Me.GroupBox1.Controls.Add(Me.cmbBoxFormat)
        Me.GroupBox1.Controls.Add(Me.PSI_id)
        Me.GroupBox1.Controls.Add(Me.tWidth)
        Me.GroupBox1.Controls.Add(Me.boardID)
        Me.GroupBox1.Controls.Add(Me.cmbPSI)
        Me.GroupBox1.Controls.Add(Me.cmbBoardType)
        Me.GroupBox1.Controls.Add(Me.cmdGetCombination)
        Me.GroupBox1.Controls.Add(Me.cmdCompute)
        Me.GroupBox1.Controls.Add(Me.GetCustomer)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.tColor4)
        Me.GroupBox1.Controls.Add(Me.tHeight)
        Me.GroupBox1.Controls.Add(Me.tLength)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.tColor3)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.tOuterLiner)
        Me.GroupBox1.Controls.Add(Me.tPaperCombination)
        Me.GroupBox1.Controls.Add(Me.tPrintcardNumber)
        Me.GroupBox1.Controls.Add(Me.tPrincardPrefix)
        Me.GroupBox1.Controls.Add(Me.tColor2)
        Me.GroupBox1.Controls.Add(Me.tBoxDescription)
        Me.GroupBox1.Controls.Add(Me.tColor1)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.lScaleID)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.tCustomerName)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1211, 180)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'cPrintcardCreated
        '
        Me.cPrintcardCreated.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.cPrintcardCreated.Location = New System.Drawing.Point(1057, 111)
        Me.cPrintcardCreated.Name = "cPrintcardCreated"
        Me.cPrintcardCreated.Size = New System.Drawing.Size(140, 22)
        Me.cPrintcardCreated.TabIndex = 143
        '
        'lDiecut
        '
        Me.lDiecut.AutoSize = True
        Me.lDiecut.Location = New System.Drawing.Point(937, 143)
        Me.lDiecut.Name = "lDiecut"
        Me.lDiecut.Size = New System.Drawing.Size(65, 16)
        Me.lDiecut.TabIndex = 142
        Me.lDiecut.Text = "Diecut ID:"
        Me.lDiecut.Visible = False
        '
        'lDimensionID
        '
        Me.lDimensionID.AutoSize = True
        Me.lDimensionID.Location = New System.Drawing.Point(413, 151)
        Me.lDimensionID.Name = "lDimensionID"
        Me.lDimensionID.Size = New System.Drawing.Size(41, 16)
        Me.lDimensionID.TabIndex = 141
        Me.lDimensionID.Text = "ID_ID"
        Me.lDimensionID.Visible = False
        '
        'cmbDiecut
        '
        Me.cmbDiecut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbDiecut.FormattingEnabled = True
        Me.cmbDiecut.Location = New System.Drawing.Point(1057, 83)
        Me.cmbDiecut.Name = "cmbDiecut"
        Me.cmbDiecut.Size = New System.Drawing.Size(140, 24)
        Me.cmbDiecut.TabIndex = 140
        '
        'cmbScale
        '
        Me.cmbScale.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbScale.FormattingEnabled = True
        Me.cmbScale.Location = New System.Drawing.Point(1057, 21)
        Me.cmbScale.Name = "cmbScale"
        Me.cmbScale.Size = New System.Drawing.Size(140, 24)
        Me.cmbScale.TabIndex = 110
        '
        'cmbUnits
        '
        Me.cmbUnits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbUnits.FormattingEnabled = True
        Me.cmbUnits.Location = New System.Drawing.Point(327, 114)
        Me.cmbUnits.Name = "cmbUnits"
        Me.cmbUnits.Size = New System.Drawing.Size(80, 24)
        Me.cmbUnits.TabIndex = 33
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(249, 118)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(14, 16)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "x"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(176, 118)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(14, 16)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "x"
        '
        'cmbJoint
        '
        Me.cmbJoint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbJoint.FormattingEnabled = True
        Me.cmbJoint.Location = New System.Drawing.Point(119, 143)
        Me.cmbJoint.Name = "cmbJoint"
        Me.cmbJoint.Size = New System.Drawing.Size(288, 24)
        Me.cmbJoint.TabIndex = 35
        '
        'cmbBoxFormat
        '
        Me.cmbBoxFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbBoxFormat.FormattingEnabled = True
        Me.cmbBoxFormat.Location = New System.Drawing.Point(119, 81)
        Me.cmbBoxFormat.Name = "cmbBoxFormat"
        Me.cmbBoxFormat.Size = New System.Drawing.Size(288, 24)
        Me.cmbBoxFormat.TabIndex = 20
        '
        'PSI_id
        '
        Me.PSI_id.AutoSize = True
        Me.PSI_id.Location = New System.Drawing.Point(708, 51)
        Me.PSI_id.Name = "PSI_id"
        Me.PSI_id.Size = New System.Drawing.Size(56, 16)
        Me.PSI_id.TabIndex = 4
        Me.PSI_id.Text = "Label17"
        Me.PSI_id.Visible = False
        '
        'tWidth
        '
        Me.tWidth.Location = New System.Drawing.Point(191, 115)
        Me.tWidth.Name = "tWidth"
        Me.tWidth.Size = New System.Drawing.Size(55, 22)
        Me.tWidth.TabIndex = 31
        '
        'boardID
        '
        Me.boardID.AutoSize = True
        Me.boardID.Location = New System.Drawing.Point(708, 18)
        Me.boardID.Name = "boardID"
        Me.boardID.Size = New System.Drawing.Size(56, 16)
        Me.boardID.TabIndex = 4
        Me.boardID.Text = "Label17"
        Me.boardID.Visible = False
        '
        'cmbPSI
        '
        Me.cmbPSI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPSI.FormattingEnabled = True
        Me.cmbPSI.Location = New System.Drawing.Point(545, 51)
        Me.cmbPSI.Name = "cmbPSI"
        Me.cmbPSI.Size = New System.Drawing.Size(157, 24)
        Me.cmbPSI.TabIndex = 50
        '
        'cmbBoardType
        '
        Me.cmbBoardType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbBoardType.FormattingEnabled = True
        Me.cmbBoardType.Location = New System.Drawing.Point(545, 21)
        Me.cmbBoardType.Name = "cmbBoardType"
        Me.cmbBoardType.Size = New System.Drawing.Size(157, 24)
        Me.cmbBoardType.TabIndex = 40
        '
        'cmdGetCombination
        '
        Me.cmdGetCombination.Location = New System.Drawing.Point(708, 80)
        Me.cmdGetCombination.Name = "cmdGetCombination"
        Me.cmdGetCombination.Size = New System.Drawing.Size(32, 27)
        Me.cmdGetCombination.TabIndex = 61
        Me.cmdGetCombination.Text = " ... "
        Me.cmdGetCombination.UseVisualStyleBackColor = True
        '
        'cmdCompute
        '
        Me.cmdCompute.Location = New System.Drawing.Point(413, 113)
        Me.cmdCompute.Name = "cmdCompute"
        Me.cmdCompute.Size = New System.Drawing.Size(32, 27)
        Me.cmdCompute.TabIndex = 34
        Me.cmdCompute.Text = " ... "
        Me.cmdCompute.UseVisualStyleBackColor = True
        '
        'GetCustomer
        '
        Me.GetCustomer.Location = New System.Drawing.Point(413, 20)
        Me.GetCustomer.Name = "GetCustomer"
        Me.GetCustomer.Size = New System.Drawing.Size(32, 27)
        Me.GetCustomer.TabIndex = 2
        Me.GetCustomer.Text = " ... "
        Me.GetCustomer.UseVisualStyleBackColor = True
        '
        'tColor4
        '
        Me.tColor4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.tColor4.Location = New System.Drawing.Point(823, 111)
        Me.tColor4.Name = "tColor4"
        Me.tColor4.Size = New System.Drawing.Size(141, 22)
        Me.tColor4.TabIndex = 100
        '
        'tHeight
        '
        Me.tHeight.Location = New System.Drawing.Point(266, 115)
        Me.tHeight.Name = "tHeight"
        Me.tHeight.Size = New System.Drawing.Size(55, 22)
        Me.tHeight.TabIndex = 32
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(453, 25)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 16)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Board Type:"
        '
        'tColor3
        '
        Me.tColor3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.tColor3.Location = New System.Drawing.Point(823, 83)
        Me.tColor3.Name = "tColor3"
        Me.tColor3.Size = New System.Drawing.Size(141, 22)
        Me.tColor3.TabIndex = 90
        '
        'tOuterLiner
        '
        Me.tOuterLiner.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.tOuterLiner.Location = New System.Drawing.Point(545, 115)
        Me.tOuterLiner.Name = "tOuterLiner"
        Me.tOuterLiner.ReadOnly = True
        Me.tOuterLiner.Size = New System.Drawing.Size(157, 22)
        Me.tOuterLiner.TabIndex = 65
        Me.tOuterLiner.TabStop = False
        '
        'tPaperCombination
        '
        Me.tPaperCombination.Location = New System.Drawing.Point(545, 82)
        Me.tPaperCombination.Name = "tPaperCombination"
        Me.tPaperCombination.ReadOnly = True
        Me.tPaperCombination.Size = New System.Drawing.Size(157, 22)
        Me.tPaperCombination.TabIndex = 60
        Me.tPaperCombination.TabStop = False
        '
        'tPrintcardNumber
        '
        Me.tPrintcardNumber.Location = New System.Drawing.Point(1131, 52)
        Me.tPrintcardNumber.Name = "tPrintcardNumber"
        Me.tPrintcardNumber.Size = New System.Drawing.Size(66, 22)
        Me.tPrintcardNumber.TabIndex = 121
        '
        'tPrincardPrefix
        '
        Me.tPrincardPrefix.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tPrincardPrefix.Location = New System.Drawing.Point(1057, 53)
        Me.tPrincardPrefix.Name = "tPrincardPrefix"
        Me.tPrincardPrefix.ReadOnly = True
        Me.tPrincardPrefix.Size = New System.Drawing.Size(66, 21)
        Me.tPrincardPrefix.TabIndex = 120
        Me.tPrincardPrefix.TabStop = False
        '
        'tColor2
        '
        Me.tColor2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.tColor2.Location = New System.Drawing.Point(823, 52)
        Me.tColor2.Name = "tColor2"
        Me.tColor2.Size = New System.Drawing.Size(141, 22)
        Me.tColor2.TabIndex = 80
        '
        'tColor1
        '
        Me.tColor1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.tColor1.Location = New System.Drawing.Point(823, 22)
        Me.tColor1.Name = "tColor1"
        Me.tColor1.Size = New System.Drawing.Size(141, 22)
        Me.tColor1.TabIndex = 70
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(1018, 114)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(40, 16)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Date:"
        '
        'lScaleID
        '
        Me.lScaleID.AutoSize = True
        Me.lScaleID.Location = New System.Drawing.Point(937, 159)
        Me.lScaleID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lScaleID.Name = "lScaleID"
        Me.lScaleID.Size = New System.Drawing.Size(59, 16)
        Me.lScaleID.TabIndex = 0
        Me.lScaleID.Text = "ScaleID:"
        Me.lScaleID.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(469, 55)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 16)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Test(PSI):"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(461, 118)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(75, 16)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Outer Liner:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(450, 85)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(86, 16)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Combination:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(71, 147)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(39, 16)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Joint:"
        '
        'lBoxFormatId
        '
        Me.lBoxFormatId.AutoSize = True
        Me.lBoxFormatId.Location = New System.Drawing.Point(220, 0)
        Me.lBoxFormatId.Name = "lBoxFormatId"
        Me.lBoxFormatId.Size = New System.Drawing.Size(56, 16)
        Me.lBoxFormatId.TabIndex = 3
        Me.lBoxFormatId.Text = "Label17"
        Me.lBoxFormatId.Visible = False
        '
        'lUnitID
        '
        Me.lUnitID.AutoSize = True
        Me.lUnitID.Location = New System.Drawing.Point(279, 0)
        Me.lUnitID.Name = "lUnitID"
        Me.lUnitID.Size = New System.Drawing.Size(44, 16)
        Me.lUnitID.TabIndex = 141
        Me.lUnitID.Text = "UnitID"
        Me.lUnitID.Visible = False
        '
        'UploadPrintcardFile
        '
        Me.UploadPrintcardFile.FileName = "OpenFileDialog1"
        '
        'cmdBrowseFile
        '
        Me.cmdBrowseFile.Location = New System.Drawing.Point(13, 13)
        Me.cmdBrowseFile.Name = "cmdBrowseFile"
        Me.cmdBrowseFile.Size = New System.Drawing.Size(98, 29)
        Me.cmdBrowseFile.TabIndex = 150
        Me.cmdBrowseFile.Text = "Upload File"
        Me.cmdBrowseFile.UseVisualStyleBackColor = True
        '
        'tFilePath
        '
        Me.tFilePath.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.tFilePath.Location = New System.Drawing.Point(118, 15)
        Me.tFilePath.Name = "tFilePath"
        Me.tFilePath.ReadOnly = True
        Me.tFilePath.Size = New System.Drawing.Size(159, 22)
        Me.tFilePath.TabIndex = 170
        '
        'tPrintcardNotes
        '
        Me.tPrintcardNotes.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.tPrintcardNotes.Location = New System.Drawing.Point(908, 205)
        Me.tPrintcardNotes.Multiline = True
        Me.tPrintcardNotes.Name = "tPrintcardNotes"
        Me.tPrintcardNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tPrintcardNotes.Size = New System.Drawing.Size(315, 70)
        Me.tPrintcardNotes.TabIndex = 190
        Me.tPrintcardNotes.Text = "Notes"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.tCustomerFile)
        Me.GroupBox2.Controls.Add(Me.cmdBrowseCustFile)
        Me.GroupBox2.Controls.Add(Me.tFilePath)
        Me.GroupBox2.Controls.Add(Me.cmdBrowseFile)
        Me.GroupBox2.Location = New System.Drawing.Point(612, 197)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(290, 80)
        Me.GroupBox2.TabIndex = 154
        Me.GroupBox2.TabStop = False
        '
        'tCustomerFile
        '
        Me.tCustomerFile.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.tCustomerFile.Location = New System.Drawing.Point(118, 48)
        Me.tCustomerFile.Name = "tCustomerFile"
        Me.tCustomerFile.ReadOnly = True
        Me.tCustomerFile.Size = New System.Drawing.Size(159, 22)
        Me.tCustomerFile.TabIndex = 180
        '
        'cmdBrowseCustFile
        '
        Me.cmdBrowseCustFile.Location = New System.Drawing.Point(13, 46)
        Me.cmdBrowseCustFile.Name = "cmdBrowseCustFile"
        Me.cmdBrowseCustFile.Size = New System.Drawing.Size(98, 29)
        Me.cmdBrowseCustFile.TabIndex = 150
        Me.cmdBrowseCustFile.Text = "Customer File"
        Me.cmdBrowseCustFile.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WebBrowser1.Location = New System.Drawing.Point(12, 288)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(1211, 343)
        Me.WebBrowser1.TabIndex = 155
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.tPanel4)
        Me.GroupBox3.Controls.Add(Me.tPanel3)
        Me.GroupBox3.Controls.Add(Me.tPanel2)
        Me.GroupBox3.Controls.Add(Me.tPanel1)
        Me.GroupBox3.Controls.Add(Me.tGlueTab)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 197)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(331, 80)
        Me.GroupBox3.TabIndex = 157
        Me.GroupBox3.TabStop = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(16, 19)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(55, 16)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Gluetab"
        '
        'tPanel4
        '
        Me.tPanel4.Location = New System.Drawing.Point(252, 41)
        Me.tPanel4.Name = "tPanel4"
        Me.tPanel4.Size = New System.Drawing.Size(53, 22)
        Me.tPanel4.TabIndex = 158
        '
        'tPanel3
        '
        Me.tPanel3.Location = New System.Drawing.Point(193, 41)
        Me.tPanel3.Name = "tPanel3"
        Me.tPanel3.Size = New System.Drawing.Size(53, 22)
        Me.tPanel3.TabIndex = 156
        '
        'tPanel2
        '
        Me.tPanel2.Location = New System.Drawing.Point(134, 41)
        Me.tPanel2.Name = "tPanel2"
        Me.tPanel2.Size = New System.Drawing.Size(53, 22)
        Me.tPanel2.TabIndex = 154
        '
        'tPanel1
        '
        Me.tPanel1.Location = New System.Drawing.Point(75, 41)
        Me.tPanel1.Name = "tPanel1"
        Me.tPanel1.Size = New System.Drawing.Size(53, 22)
        Me.tPanel1.TabIndex = 152
        '
        'tGlueTab
        '
        Me.tGlueTab.Location = New System.Drawing.Point(19, 41)
        Me.tGlueTab.Name = "tGlueTab"
        Me.tGlueTab.Size = New System.Drawing.Size(50, 22)
        Me.tGlueTab.TabIndex = 150
        Me.tGlueTab.Text = "35"
        '
        'tBoardWidth
        '
        Me.tBoardWidth.Location = New System.Drawing.Point(173, 16)
        Me.tBoardWidth.Name = "tBoardWidth"
        Me.tBoardWidth.ReadOnly = True
        Me.tBoardWidth.Size = New System.Drawing.Size(53, 22)
        Me.tBoardWidth.TabIndex = 162
        '
        'tBoardLength
        '
        Me.tBoardLength.Location = New System.Drawing.Point(63, 16)
        Me.tBoardLength.Name = "tBoardLength"
        Me.tBoardLength.ReadOnly = True
        Me.tBoardLength.Size = New System.Drawing.Size(53, 22)
        Me.tBoardLength.TabIndex = 160
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(9, 19)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(51, 16)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Length:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(122, 19)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(45, 16)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Width:"
        '
        'tFlap
        '
        Me.tFlap.Location = New System.Drawing.Point(173, 49)
        Me.tFlap.Name = "tFlap"
        Me.tFlap.Size = New System.Drawing.Size(53, 22)
        Me.tFlap.TabIndex = 166
        '
        'tBoxHeight
        '
        Me.tBoxHeight.Location = New System.Drawing.Point(63, 49)
        Me.tBoxHeight.Name = "tBoxHeight"
        Me.tBoxHeight.Size = New System.Drawing.Size(53, 22)
        Me.tBoxHeight.TabIndex = 164
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(9, 51)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(50, 16)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "Height:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(122, 51)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(38, 16)
        Me.Label27.TabIndex = 1
        Me.Label27.Text = "Flap:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label27)
        Me.GroupBox4.Controls.Add(Me.tBoardWidth)
        Me.GroupBox4.Controls.Add(Me.tBoardLength)
        Me.GroupBox4.Controls.Add(Me.Label26)
        Me.GroupBox4.Controls.Add(Me.tFlap)
        Me.GroupBox4.Controls.Add(Me.tBoxHeight)
        Me.GroupBox4.Controls.Add(Me.Label24)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Location = New System.Drawing.Point(349, 197)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(257, 80)
        Me.GroupBox4.TabIndex = 157
        Me.GroupBox4.TabStop = False
        '
        'PrintCard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1235, 643)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.tPrintcardNotes)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.lUnitID)
        Me.Controls.Add(Me.lBoxFormatId)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "PrintCard"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "New PrintCard"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents tCustomerName As System.Windows.Forms.TextBox
    Friend WithEvents tBoxDescription As System.Windows.Forms.TextBox
    Friend WithEvents tLength As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbBoardType As System.Windows.Forms.ComboBox
    Friend WithEvents cmdGetCombination As System.Windows.Forms.Button
    Friend WithEvents GetCustomer As System.Windows.Forms.Button
    Friend WithEvents tColor4 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents tColor3 As System.Windows.Forms.TextBox
    Friend WithEvents tOuterLiner As System.Windows.Forms.TextBox
    Friend WithEvents tPaperCombination As System.Windows.Forms.TextBox
    Friend WithEvents tColor2 As System.Windows.Forms.TextBox
    Friend WithEvents tColor1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents tPrincardPrefix As System.Windows.Forms.TextBox
    Friend WithEvents boardID As System.Windows.Forms.Label
    Friend WithEvents cmbPSI As System.Windows.Forms.ComboBox
    Friend WithEvents PSI_id As System.Windows.Forms.Label
    Friend WithEvents cmbBoxFormat As System.Windows.Forms.ComboBox
    Friend WithEvents lBoxFormatId As System.Windows.Forms.Label
    Friend WithEvents tHeight As System.Windows.Forms.TextBox
    Friend WithEvents tWidth As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lDimensionID As System.Windows.Forms.Label
    Friend WithEvents cmbUnits As System.Windows.Forms.ComboBox
    Friend WithEvents lUnitID As System.Windows.Forms.Label
    Friend WithEvents cmbScale As System.Windows.Forms.ComboBox
    Friend WithEvents lScaleID As System.Windows.Forms.Label
    Friend WithEvents tPrintcardNumber As System.Windows.Forms.TextBox
    Friend WithEvents cmbDiecut As System.Windows.Forms.ComboBox
    Friend WithEvents lDiecut As System.Windows.Forms.Label
    Friend WithEvents UploadPrintcardFile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents cmdBrowseFile As System.Windows.Forms.Button
    Friend WithEvents tFilePath As System.Windows.Forms.TextBox
    Friend WithEvents cmbJoint As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents cmdCompute As System.Windows.Forms.Button
    Friend WithEvents cPrintcardCreated As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents tPrintcardNotes As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents tCustomerFile As System.Windows.Forms.TextBox
    Friend WithEvents cmdBrowseCustFile As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents tPanel4 As System.Windows.Forms.TextBox
    Friend WithEvents tPanel3 As System.Windows.Forms.TextBox
    Friend WithEvents tPanel2 As System.Windows.Forms.TextBox
    Friend WithEvents tPanel1 As System.Windows.Forms.TextBox
    Friend WithEvents tGlueTab As System.Windows.Forms.TextBox
    Friend WithEvents tBoardLength As System.Windows.Forms.TextBox
    Friend WithEvents tBoardWidth As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents tBoxHeight As System.Windows.Forms.TextBox
    Friend WithEvents tFlap As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
End Class
