﻿Imports Npgsql
Imports System.IO

Public Class ClassPrintcard
    Dim SQLConn As DataConnection = New DataConnection
    Public ErrorFlag As Short = 0 'Trigger to 1 and abort any transaction

    'ErrorFlag for SavePrintcard = 1
    Public Sub SavePrintcard(ByVal CustomerID As Integer, ByVal BoxDescription As String, _
                             ByVal BoxFormatID As Integer, ByVal FluteID As Integer, _
                             ByVal TestID As Integer, ByVal JointID As Integer, ByVal Paper_combinationID As Integer, _
                             ByVal DimensionID As Integer, ByVal Color1 As String, ByVal Color2 As String, _
                             ByVal Color3 As String, ByVal Color4 As String, ByVal Flap As String, ByVal UnitID As String, _
                             ByVal ScaleID As Integer, ByVal DiecutID As Integer, ByVal PrintcardNo As Integer, _
                             ByVal FilenameID As Integer, ByVal DateCreated As String, ByVal PrintCardNotes As String, _
                             ByVal BoardLength As Double, ByVal BoardWidth As Double, _
                             ByVal BoxHeight As Single, ByVal GlueTab As Single, _
                             ByVal Panel1 As Single, ByVal Panel2 As Single, ByVal Panel3 As Single, ByVal Panel4 As Single, _
                             ByVal CustomerFileID As Integer)


        Try
           
        Catch ex As Exception
            ErrorFlag = 1
            'MsgBox(ex.Message & " Error in SavePrintcard Class: ClassPrintcard")
        End Try

        If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
        SQLConn.sql = "INSERT INTO printcard( " & _
                        "customer_id, box_description, boxformat_id, flute_id, test_id, " & _
                        " joint_id, paper_combination_id, dimension_id, color_1, color_2, " & _
                        " color_3, color_4, flap, unit_id, scale_id, diecut_id, printcardno, " & _
                        " filename_id, date_created, notes, boardlength, boardwidth, " & _
                        " boxheight, gluetab, panel1, panel2, panel3, panel4, customer_file_id) " & _
                        " VALUES (@customer_id, @box_description, @boxformat_id, @flute_id, @test_id, " & _
                                    "@joint_id, @paper_combination_id, @dimension_id, @color_1, @color_2, " & _
                                    "@color_3, @color_4, @flap, @unit_id, @scale_id, @diecut_id, @printcardno, " & _
                                    "@filename_id, @date_created, @notes, @boardlength, @boardwidth, @boxheight, " & _
                                    "@gluetab, @panel1, @panel2, @panel3, @panel4, @customer_file_id);"

        'Initialize SqlCommand object for insert. 
        SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
        'Add the values
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@customer_id", CustomerID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@box_description", BoxDescription))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@boxformat_id", BoxFormatID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@flute_id", FluteID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@test_id", TestID))

        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@joint_id", JointID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@paper_combination_id", Paper_combinationID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@dimension_id", DimensionID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@color_1", Color1))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@color_2", Color2))

        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@color_3", Color3))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@color_4", Color4))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@flap", Flap))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@unit_id", UnitID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@scale_id", ScaleID))

        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@diecut_id", DiecutID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@printcardno", PrintcardNo))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@filename_id", FilenameID))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@date_created", DateCreated))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@notes", PrintCardNotes))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@boardlength", BoardLength))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@boardwidth", BoardWidth))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@boxheight", BoxHeight))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@gluetab", GlueTab))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@panel1", Panel1))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@panel2", Panel2))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@panel3", Panel3))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@panel4", Panel4))
        SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@customer_file_id", CustomerFileID))
        '@boardlength, @boardwidth, @boxheight, " & _
        '                            "@gluetab, @panel1, @panel2, @panel3, @panel4, @customer_file_id
        'Execute the Query
        SQLConn.cmd.ExecuteNonQuery()

        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
    End Sub
    'ErrorFlag for InsertPrintcardSeries = 2
    Public Sub InsertPrintcardSeries(ByVal CustomerID As Integer, ByVal PrintCardNo As Integer)

        Try
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            If PrintCardNo = 1 Then 'We will use insert since this is the first printcard created for this customer.
                SQLConn.sql = "INSERT INTO printcard_series(customer_id,printcardno,date_updated) " & _
                              "VALUES(@customer_id,@printcardno,@date_created)"
                'Initialize SqlCommand object for insert. 
                SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
                'Add the values
                SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@customer_id", CustomerID))
                SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@printcardno", PrintCardNo))
                SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@date_created", Now()))
                'Execute the Query
                SQLConn.cmd.ExecuteNonQuery()

            Else ' Else we will update the existing printcard series 
                SQLConn.sql = "UPDATE printcard_series SET printcardno=@printcardno, date_updated=@date_updated " & _
                              "WHERE customer_id=@customer_id"

                'Initialize SqlCommand object for update. 
                SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
                'Add the values                
                SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@printcardno", PrintCardNo))
                SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@date_updated", Now()))
                SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@customer_id", CustomerID))
                'Execute the Query
                SQLConn.cmd.ExecuteNonQuery()

            End If


            SQLConn.conn.Close()
            SQLConn.conn.ClearPool()
        Catch ex As Exception
            ErrorFlag = 2
            'MsgBox(ex.Message & "! Error in ClassPrintcard.vb Module InsertPrintcardSeries.")
        End Try

    End Sub

    'Error flag = 3
    Public Function InsertNewID(ByVal Length As Integer, ByVal Width As Integer, ByVal Height As Integer, ByVal unit_id As Integer) As Integer
        'If the defined Inside Dimension have no existing record, then we will insert the new I.D. and get its table ID
        Dim NewDimensionID As Integer
        Try
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "INSERT INTO paper_dimension(length,width,height,unit_id,date_created) " & _
                          "VALUES(@length,@width,@height,@unit_id,@date_created)"
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)

            'Add the values
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@length", Length))
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@width", Width))
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@height", Height))
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@unit_id", unit_id))
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@date_created", Now()))

            'Execute the Query
            SQLConn.cmd.ExecuteNonQuery()

            SQLConn.sql = "SELECT lastval() FROM paper_dimension;"
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)

            While SQLConn.dr.Read                
                NewDimensionID = SQLConn.dr.GetValue(0)
            End While

        Catch ex As Exception
            ErrorFlag = 3
            'MsgBox(ex.Message & "! Error in InsertNewID, ClassPrintcard.vb")
        End Try

        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return NewDimensionID
    End Function

    'Error flag is 4
    Public Function upLoadImageOrFile(ByVal sFilePath As String, ByVal sFileType As String) As Integer
        Dim imageData As Byte()
        Dim sFileName As String
        Dim FileID As Integer
        Try

            'Read Image Bytes into a byte array 

            'Initialize SQL Server Connection 
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()

            'Convert File to bytes Array
            imageData = ReadFile(sFilePath)

            sFileName = System.IO.Path.GetFileName(sFilePath)

            'Set insert query 
            SQLConn.sql = "INSERT INTO graphicfiles(fileloaded, filename, filetype, date_created)" & _
                          "VALUES (@fileloaded, @filename, @filetype, @date_created)"

            'Initialize SqlCommand object for insert. 
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)

            'We are passing File Name and Image byte data as sql parameters. 

            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@filename", sFileName)) 'File path/name
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@fileloaded", DirectCast(imageData, Object))) ' actual file contents

            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@filetype", sFileType))
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@date_created", Now()))

            'Execute the Query
            SQLConn.cmd.ExecuteNonQuery()

            SQLConn.sql = "SELECT lastval() FROM graphicfiles;"
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)

            While SQLConn.dr.Read
                FileID = SQLConn.dr.GetValue(0)
            End While


        Catch ex As Exception
            ErrorFlag = 4
            'MessageBox.Show(ex.ToString())
            'MsgBox("File could not uploaded: ClassPrintcard: upLoadImageOrFile")

        End Try

        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return FileID
    End Function

    Public Function UploadCustomerFile(ByVal cCustomerFile As String, ByVal sFileType As String) As Integer
        Dim imageData As Byte()
        Dim sFileName As String
        Dim FileID As Integer
        Try

            'Read Image Bytes into a byte array 

            'Initialize SQL Server Connection 
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()

            'Convert File to bytes Array
            imageData = ReadFile(cCustomerFile)

            sFileName = System.IO.Path.GetFileName(cCustomerFile)

            'Set insert query 
            SQLConn.sql = "INSERT INTO customerfile(fileloaded, filename, filetype, date_created)" & _
                          "VALUES (@fileloaded, @filename, @filetype, @date_created)"

            'Initialize SqlCommand object for insert. 
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)

            'We are passing File Name and Image byte data as sql parameters. 

            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@filename", sFileName)) 'File path/name
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@fileloaded", DirectCast(imageData, Object))) ' actual file contents

            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@filetype", sFileType))
            SQLConn.cmd.Parameters.Add(New NpgsqlParameter("@date_created", Now()))

            'Execute the Query
            SQLConn.cmd.ExecuteNonQuery()

            SQLConn.sql = "SELECT lastval() FROM graphicfiles;"
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)

            While SQLConn.dr.Read
                FileID = SQLConn.dr.GetValue(0)
            End While


        Catch ex As Exception
            ErrorFlag = 4
            'MessageBox.Show(ex.ToString())
            'MsgBox("File could not uploaded: ClassPrintcard: upLoadImageOrFile")

        End Try

        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return FileID
    End Function

    Private Function ReadFile(ByVal sPath As String) As Byte()

        'Initialize byte array with a null value initially. 
        Dim data As Byte() = Nothing

        'Use FileInfo object to get file size. 
        Dim fInfo As New FileInfo(sPath)
        Dim numBytes As Long = fInfo.Length

        'Open FileStream to read file 
        Dim fStream As New FileStream(sPath, FileMode.Open, FileAccess.Read)

        'Use BinaryReader to read file stream into byte array. 
        Dim br As New BinaryReader(fStream)

        'When you use BinaryReader, you need to supply number of bytes to read from file. 
        'In this case we want to read entire file. So supplying total number of bytes. 
        data = br.ReadBytes(CInt(numBytes))

        Return data
    End Function

    Public Sub downLoadFile(ByVal id As Long, ByVal sFileName As String, ByVal sFileExtension As String)

        'For Document
        Try
            'Get image data from gridview column. 
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "Select fileloaded from graphicfiles WHERE id=" & id

            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)

            'Get image data from DB
            Dim fileData As Byte() = DirectCast(SQLConn.cmd.ExecuteScalar(), Byte())

            Dim sTempFileName As String = Application.StartupPath & "\" & sFileName

            If Not fileData Is Nothing Then

                'Read image data into a file stream 
                Using fs As New FileStream(sFileName, FileMode.OpenOrCreate, FileAccess.Write)
                    fs.Write(fileData, 0, fileData.Length)
                    'Set image variable value using memory stream. 
                    fs.Flush()
                    fs.Close()
                End Using

                'Open File

                Process.Start(sFileName)

            End If

        Catch ex As Exception

            MsgBox(ex.Message)
        End Try

        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

    End Sub

    Public Sub ViewCustomerFile(ByVal CustomerFileID As Long, ByVal sFileName As String, ByVal sFileExtension As String)

        'For Document
        Try
            'Get image data from gridview column. 
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "Select fileloaded from customerfile WHERE id=" & CustomerFileID

            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)

            'Get image data from DB
            Dim fileData As Byte() = DirectCast(SQLConn.cmd.ExecuteScalar(), Byte())

            Dim sTempFileName As String = Application.StartupPath & "\" & sFileName

            If Not fileData Is Nothing Then

                'Read image data into a file stream 
                Using fs As New FileStream(sFileName, FileMode.OpenOrCreate, FileAccess.Write)
                    fs.Write(fileData, 0, fileData.Length)
                    'Set image variable value using memory stream. 
                    fs.Flush()
                    fs.Close()
                End Using

                Process.Start(sFileName)
                'FilePreview.Show()
                'FilePreview.WebBrowser1.Navigate(sFileName)

            End If

        Catch ex As Exception

            MsgBox(ex.Message)
        End Try

        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

    End Sub
    Public Sub GetPrintcardList(ByVal TableGrid As DataGridView, ByVal DateYear As String, ByVal DateMonth As String, Optional ByVal NumOfRecords As Integer = 50)
        Dim param As String

        Try
            If DateMonth = "" Then
                param = "YYYY"
            Else
                param = "YYYYMM"
            End If
            Dim YearAndMonth As String = DateYear + DateMonth
            'columns here must match to the search function below
            SQLConn.sql = "SELECT printcard.filename_id as fileid,customer.contact_id as id, " & _
                                  " contact.organization_name as organization_name, " & _
                                  " graphicfiles.filename as filename, " & _
                                  " (trim(to_char(paper_dimension.length,'999999')) || ' X ' || trim(to_char(paper_dimension.width,'99999')) || ' X ' || trim(to_char(paper_dimension.height,'99999'))) as insidedimension, " & _
                                  " graphicfiles.date_created as date_created, " & _
                                  " (customer.printcard_prefix || " & _
                                    " CASE char_length(trim(to_char(printcardno,'999999'))) WHEN 1 Then '-PC-000' " & _
                                        " WHEN 2 Then '-PC-00' " & _
                                        " WHEN 3 Then '-PC-0' " & _
                                    " ELSE '-PC-' " & _
                                    " END || printcard.printcardno) as printcardno, " & _
                                  " diecut.diecut_number as diecut_number, " & _
                                  "(racks.rack_number || racks.rack_column) as racklocation, " & _
                                  " printcard.box_description as box_description, printcard.color_1 as color1, printcard.color_2 as color2, printcard.color_3 as color3," & _
                                  " printcard.color_4 as color4, boxformat.description as boardtypeid, (flute.flute || '-') || flute.description as fluteid, test.value as testid," & _
                                  " joint.description as jointid, printcard.paper_combination_id as combinationid, printcard.dimension_id as dimensionid," & _
                                  " scale.description as scaleid, trim(to_char(printcard.boardlength,'999999')) || ' X ' || trim(to_char(printcard.boardwidth,'999999')) as boardsize,graphicfiles.filetype as filetype,printcard.printcardno as printcopyno, " & _
                                  " printcard.customer_file_id as customer_file_id,customerfile.filename as customerfile,customerfile.filetype as customerfiletype" & _
                         " FROM (((((printcard " & _
                         " INNER JOIN customer ON printcard.customer_id=customer.id) " & _
                         " INNER JOIN graphicfiles ON printcard.filename_id=graphicfiles.id)" & _
                         " INNER JOIN diecut ON printcard.diecut_id=diecut.id)" & _
                         " INNER JOIN racks ON diecut.rack_id=racks.id)" & _
                         " INNER JOIN contact ON customer.contact_id=contact.id " &
                         " INNER JOIN boxformat ON printcard.boxformat_id=boxformat.id " & _
                         " INNER JOIN flute ON printcard.flute_id=flute.id " & _
                         " INNER JOIN test ON printcard.test_id=test.id " &
                         " INNER JOIN scale ON printcard.scale_id=scale.id " & _
                         " INNER JOIN joint ON printcard.joint_id=joint.id " & _
                         " INNER JOIN paper_dimension ON printcard.dimension_id=paper_dimension.id " & _
                         " INNER JOIN customerfile ON printcard.customer_file_id=customerfile.id) " & _
                         " WHERE (to_char(printcard.date_created,'" & param & "')='" & YearAndMonth & "')" & _
                         " ORDER BY printcard.filename_id DESC LIMIT " & NumOfRecords

            SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
            SQLConn.da.Fill(SQLConn.ds, "graphicfiles")
            TableGrid.DataSource = SQLConn.ds.Tables("graphicfiles")

        Catch ex As Npgsql.NpgsqlException
            MsgBox(ex.Message)
        Catch ex As ApplicationException
            MsgBox(ex.Message)
        End Try

        SQLConn.conn.ClearPool()

    End Sub

    Public Function DeleteData(ByVal TableName As String, ByVal TableID As Integer) As Boolean
        Try
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "DELETE FROM " & TableName & " WHERE id= " & TableID
            'Initialize SqlCommand object for insert. 
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            'Execute the Query
            SQLConn.cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return False
            MsgBox(ex.Message)
        End Try
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
        Return True
    End Function

    Public Function UpdateData(ByVal TableName As String, ByVal CustomerID As Integer, ByVal FieldName As String, ByVal Value As Integer) As Boolean
        Try
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "UPDATE " & TableName & " SET " & FieldName & "=" & Value & " WHERE customer_id=" & CustomerID
            'Initialize SqlCommand object for insert. 
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            'Execute the Query
            SQLConn.cmd.ExecuteNonQuery()
        Catch ex As Exception
            Return False
            MsgBox(ex.Message)
        End Try
        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()
        Return True
    End Function

    Public Function CreateCopyFromFile(ByVal id As Long, ByVal sFileName As String, ByVal sFileExtension As String) As String
        'For Document
        Dim sTempFileName As String = ""
        Try
            'Get image data from gridview column. 
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "Select fileloaded from graphicfiles WHERE id=" & id

            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)

            'Get image data from DB
            Dim fileData As Byte() = DirectCast(SQLConn.cmd.ExecuteScalar(), Byte())

            sTempFileName = Application.StartupPath & "\" & sFileName

            If Not fileData Is Nothing Then

                'Read image data into a file stream 
                Using fs As New FileStream(sFileName, FileMode.OpenOrCreate, FileAccess.Write)
                    fs.Write(fileData, 0, fileData.Length)
                    'Set image variable value using memory stream. 
                    fs.Flush()
                    fs.Close()
                End Using

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        SQLConn.conn.Close()
        SQLConn.conn.ClearPool()

        Return sTempFileName
    End Function

    'Copy printcard funtions
    Function GetStringFromTable(ByVal id As Integer, ByVal ColumnName As String, ByVal TableName As String) As String
        Dim iResStr As String = ""
        Try
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "SELECT " & ColumnName & " FROM " & TableName & " WHERE id=" & id
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While (SQLConn.dr.Read)
                iResStr = SQLConn.dr.GetValue(0)
            End While
            SQLConn.conn.Close()
            SQLConn.conn.ClearPool()
        Catch ex As Exception
            MsgBox(ex.Message & " Error in GetStringFromTable function: Class ClassPrintcard")
        End Try

        Return iResStr
    End Function
    Public Function GetFlute(ByVal id As Integer) As String
        Dim iResStr As String = ""
        Try
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "Select (flute || '-') || description as boardtype FROM flute WHERE id =" & id
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While (SQLConn.dr.Read)
                iResStr = SQLConn.dr.GetValue(0)
            End While
            SQLConn.conn.Close()
            SQLConn.conn.ClearPool()
        Catch ex As Exception
            MsgBox(ex.Message & " Error in GetFlute function: Class ClassPrintcard")
        End Try

        Return iResStr
    End Function

    Public Sub Search(ByVal TableGrid As DataGridView, ByVal DateYear As String, ByVal DateMonth As String, ByVal Column As String, TextToSearch As String,Optional ByVal NumOfRecords As Integer = 50)
        Dim param As String

        Try
            If DateMonth = "" Then
                param = "YYYY"
            Else
                param = "YYYYMM"
            End If
            Dim YearAndMonth As String = DateYear + DateMonth

            'Columns /query here must match to function GetPrintcardList above
            SQLConn.sql = "SELECT printcard.filename_id as fileid,customer.contact_id as id, " & _
                                  " contact.organization_name as organization_name, " & _
                                  " graphicfiles.filename as filename, " & _
                                  " (trim(to_char(paper_dimension.length,'999999')) || ' X ' || trim(to_char(paper_dimension.width,'99999')) || ' X ' || trim(to_char(paper_dimension.height,'99999'))) as insidedimension, " & _
                                  " graphicfiles.date_created as date_created, " & _
                                  " (customer.printcard_prefix || " & _
                                    " CASE char_length(trim(to_char(printcardno,'999999'))) WHEN 1 Then '-PC-000' " & _
                                        " WHEN 2 Then '-PC-00' " & _
                                        " WHEN 3 Then '-PC-0' " & _
                                    " ELSE '-PC-' " & _
                                    " END || printcard.printcardno) as printcardno, " & _
                                  " diecut.diecut_number as diecut_number, " & _
                                  "(racks.rack_number || racks.rack_column) as racklocation, " & _
                                  " printcard.box_description as box_description, printcard.color_1 as color1, printcard.color_2 as color2, printcard.color_3 as color3," & _
                                  " printcard.color_4 as color4, boxformat.description as boardtypeid, (flute.flute || '-') || flute.description as fluteid, test.value as testid," & _
                                  " joint.description as jointid, printcard.paper_combination_id as combinationid, printcard.dimension_id as dimensionid," & _
                                  " scale.description as scaleid, trim(to_char(printcard.boardlength,'999999')) || ' X ' || trim(to_char(printcard.boardwidth,'999999')) as boardsize,graphicfiles.filetype as filetype,printcard.printcardno as printcopyno, " & _
                                  " printcard.customer_file_id as customer_file_id,customerfile.filename as customerfile,customerfile.filetype as customerfiletype" & _
                         " FROM (((((printcard " & _
                         " INNER JOIN customer ON printcard.customer_id=customer.id) " & _
                         " INNER JOIN graphicfiles ON printcard.filename_id=graphicfiles.id)" & _
                         " INNER JOIN diecut ON printcard.diecut_id=diecut.id)" & _
                         " INNER JOIN racks ON diecut.rack_id=racks.id)" & _
                         " INNER JOIN contact ON customer.contact_id=contact.id " &
                         " INNER JOIN boxformat ON printcard.boxformat_id=boxformat.id " & _
                         " INNER JOIN flute ON printcard.flute_id=flute.id " & _
                         " INNER JOIN test ON printcard.test_id=test.id " &
                         " INNER JOIN scale ON printcard.scale_id=scale.id " & _
                         " INNER JOIN joint ON printcard.joint_id=joint.id " & _
                         " INNER JOIN paper_dimension ON printcard.dimension_id=paper_dimension.id " & _
                         " INNER JOIN customerfile ON printcard.customer_file_id=customerfile.id) " & _
                         " WHERE (to_char(printcard.date_created,'" & param & "')='" & YearAndMonth & "') AND " & Column & " ::text ilike '%" & TextToSearch & "%'" & _
                         " ORDER BY printcard.filename_id DESC LIMIT " & NumOfRecords

            SQLConn.da = New NpgsqlDataAdapter(SQLConn.sql, SQLConn.conn)
            SQLConn.da.Fill(SQLConn.ds, "graphicfiles")
            TableGrid.DataSource = SQLConn.ds.Tables("graphicfiles")

        Catch ex As Npgsql.NpgsqlException
            MsgBox(ex.Message)
        Catch ex As ApplicationException
            MsgBox(ex.Message)
        End Try

        SQLConn.conn.ClearPool()

    End Sub

    Public Function CheckExistingPrincardNumber(ByVal CustomerID As Integer, ByVal PrintcardNumber As Integer) As Integer
        CheckExistingPrincardNumber = 0
        Try
            If SQLConn.conn.State = ConnectionState.Closed Then SQLConn.conn.Open()
            SQLConn.sql = "Select count(*) FROM printcard WHERE customer_id =" & CustomerID & " AND printcardno=" & PrintcardNumber
            SQLConn.cmd = New NpgsqlCommand(SQLConn.sql, SQLConn.conn)
            SQLConn.dr = SQLConn.cmd.ExecuteReader(CommandBehavior.CloseConnection)
            While (SQLConn.dr.Read)
                CheckExistingPrincardNumber = SQLConn.dr.GetValue(0)
            End While
            SQLConn.conn.Close()
            SQLConn.conn.ClearPool()
        Catch ex As Exception
            MsgBox(ex.Message & " Error in GetFlute function: Class ClassPrintcard")
        End Try
        Return CheckExistingPrincardNumber
    End Function
End Class
