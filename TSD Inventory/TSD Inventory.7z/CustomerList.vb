﻿Public Class CustomerList
    Dim objCustomerList As Customer
    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Me.Cursor = Cursors.WaitCursor
        Dim p As ExportRptProgress = ExportRptProgress.ShowProgress(Me)
        p.UpdateProgress(10, "10%", "Loading customer data...")
        For Each CustomerList In Me.CustomerGridList.SelectedRows
            PrintCard.customer_id = CustomerList.cells("id").value
            PrintCard.Customer_Name = CustomerList.cells("orgname").value
        Next
        p.UpdateProgress(20, "20%", "Loading customer data...")
        PrintCard.tCustomerName.Text = PrintCard.Customer_Name
        PrintCard.tPrincardPrefix.Text = objCustomerList.GetCustomerPrefix(PrintCard.customer_id) & "-PC-"
        p.UpdateProgress(50, "50%", "Loading customer data...")
        PrintCard.tPrintcardNumber.Text = objCustomerList.GetPrintcardNum(PrintCard.customer_id)
        p.UpdateProgress(100, "100%", "Loading customer data...")
        'Get printcard series for this customer
        objCustomerList = Nothing
        p.CloseProgress()
        Me.Cursor = Cursors.Default

        Me.Close()

    End Sub

    Private Sub CustomerList_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        objCustomerList = New Customer
        objCustomerList.GetCustomerList(Me.CustomerGridList)
    End Sub

End Class